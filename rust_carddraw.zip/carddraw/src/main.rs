use sdl2::event::Event;
use sdl2::image::LoadTexture;
use sdl2::keyboard::Keycode;
use sdl2::pixels::Color;
use sdl2::rect::Rect;
use sdl2::render::{Canvas, TextureCreator};
use sdl2::ttf::Font;
use sdl2::video::{Window, WindowContext};
use std::path::Path;
use std::fs::File;
use std::io::Read;
use std::time::{Duration, Instant};
use rand::seq::SliceRandom;
use uname::uname;

// Card sprite sheet constants
const SPRITE_SHEET_PATH: &str = "cards.png";
const CARD_WIDTH: u32 = 148;   // Width of each card in pixels
const CARD_HEIGHT: u32 = 214;  // Height of each card in pixels
const CARDS_PER_ROW: u32 = 13; // Number of cards in each row of the sprite sheet
const CARD_X_OFFSET: u32 = 0; // X offset to start of first card
const CARD_Y_OFFSET: u32 = 0; // Y offset to start of first card
const CARD_SPACING_X: u32 = 0; // Horizontal spacing between cards in sprite sheet
const CARD_SPACING_Y: u32 = 0; // Vertical spacing between cards in sprite sheet
const DANGER_TEMPERATURE : f32= 80.0; // threshold at which the temperature starts flashing

// Window and display constants
const WINDOW_WIDTH: u32 = 800;
const WINDOW_HEIGHT: u32 = 600;
const NUM_CARDS_TO_DRAW: usize = 5;

// Read temperature on a Raspberry Pi
fn get_temperature()-> f32 {
    let mut file = File::open("/sys/class/thermal/thermal_zone0/temp").unwrap();
    let mut contents = String::new();
    file.read_to_string(&mut contents).unwrap();
    let temp: f32 = contents.trim().parse().unwrap();
    temp / 1000.0
}

fn is_pi_system() -> bool {
    let info = uname().unwrap();
    if info.nodename!="raspberrypi" {
        return false;
    }
    if info.machine!="aarch64"{
        return false;
        }
    true
}

// Utility function to render text
fn render_text<'a>(
    canvas: &mut Canvas<Window>,
    font: &Font<'a, 'static>,
    texture_creator: &'a TextureCreator<WindowContext>,
    text: &str,
    x: i32,
    y: i32,
    color: Color,
) {
    let surface = font.render(text).blended(color).unwrap();
    let texture = texture_creator
        .create_texture_from_surface(&surface)
        .unwrap();
    let text_rect = Rect::new(x, y, surface.width(), surface.height());
    canvas.copy(&texture, None, text_rect).unwrap();
}

fn main() -> Result<(), String> {
    let mut counter=0;
    let mut flashing = true;
    let mut show_flash = false;
    let mut temperature;
    let is_pi = is_pi_system();
    let sdl_context = sdl2::init()?;
    let video_subsystem = sdl_context.video()?;
    let ttf_context = sdl2::ttf::init().map_err(|e| e.to_string())?;
    

    let window = video_subsystem
        .window("Random Card Draw", WINDOW_WIDTH, WINDOW_HEIGHT)
        .position_centered()    
        .build()
        .map_err(|e| e.to_string())?;

    let mut canvas = window.into_canvas().build().map_err(|e| e.to_string())?;
    let texture_creator = canvas.texture_creator();
    let mut rng = rand::rng();

    // Load the sprite sheet
    let texture = texture_creator.load_texture(SPRITE_SHEET_PATH).expect("Could not load sprite sheet");

    // Load font
    let font_path = Path::new("assets/fonts/cps.ttf");
    let font_size = 24;
    let font = ttf_context.load_font(font_path, font_size).expect("Could not load font");
       

    // Randomly select 5 unique card indices (0-51)
    let mut card_indices: Vec<u32> = (0..52).collect();
    card_indices.shuffle(&mut rng);
    let mut selected_cards = &card_indices[..NUM_CARDS_TO_DRAW];
    let mut temp_str=String::from("");

    // Main game loop
    let mut event_pump = sdl_context.event_pump()?;
    'running: loop {
        // Handle events
        for event in event_pump.poll_iter() {
            match event {
                Event::Quit { .. } |
                Event::KeyDown { keycode: Some(Keycode::ESCAPE), .. } => break 'running,
                Event::KeyDown { keycode: Some(Keycode::Space), .. } => { // reshuffles cards
                    card_indices.shuffle(&mut rng);
                    selected_cards = &card_indices[..NUM_CARDS_TO_DRAW];                    
                }
                _ => {}
            }
        }

        let start = Instant::now();
        // Clear the screen
        canvas.set_draw_color(Color::RGB(0, 128, 0)); // Green background
        canvas.clear();

        // Draw the selected cards
        for (i, &card_index) in selected_cards.iter().enumerate() {
            // Calculate source rectangle in sprite sheet
            let src_x = CARD_X_OFFSET + (card_index % CARDS_PER_ROW) * (CARD_WIDTH + CARD_SPACING_X);
            let src_y = CARD_Y_OFFSET + (card_index / CARDS_PER_ROW) * (CARD_HEIGHT + CARD_SPACING_Y);
            
            let src_rect = Rect::new(src_x as i32, src_y as i32, CARD_WIDTH, CARD_HEIGHT);

            // Calculate destination rectangle (spread cards across screen)
            let dest_x = 25 + (i as u32 * 150);
            let dest_y = 200;
            let dest_rect = Rect::new(dest_x as i32, dest_y as i32, CARD_WIDTH , CARD_HEIGHT );

            // Copy the card texture to the canvas
            canvas.copy(&texture, src_rect, dest_rect)?;
        }
        let mut index=0;
        for (i, &card_index) in card_indices.iter().enumerate() {
            // Calculate source rectangle in sprite sheet
            let src_x = CARD_X_OFFSET + (card_index % CARDS_PER_ROW) * (CARD_WIDTH + CARD_SPACING_X);
            let src_y = CARD_Y_OFFSET + (card_index / CARDS_PER_ROW) * (CARD_HEIGHT + CARD_SPACING_Y);
            
            let src_rect = Rect::new(src_x as i32, src_y as i32, CARD_WIDTH, CARD_HEIGHT);

            // Calculate destination rectangle (spread cards across screen)
            let dest_x = 25 + (i % 15 ) * 50;
            let dest_y = if index<15 {80} else {135};
            let dest_rect = Rect::new(dest_x as i32, dest_y as i32, CARD_WIDTH/4 , CARD_HEIGHT/4 );

            // Copy the card texture to the canvas
            canvas.copy(&texture, src_rect, dest_rect)?;
            index +=1;
        }
        if is_pi {
            counter += 1;
            if counter==60 {
                counter = 0;
                temperature = get_temperature();
                let time = start.elapsed();
                temp_str.clear();
                temp_str.push_str( &format!("Temperature: {temperature} C Duration: ").to_string());
                temp_str.push_str(format!("{:?} μs",time.as_nanos()/1000u128).as_str());
                flashing = temperature >= DANGER_TEMPERATURE;
                if counter %20==0 {
                    show_flash = !show_flash;
                }
                
            }

            // Show temperature
            if !flashing {
                show_flash=true;
            }
            if temp_str !="" && show_flash  {
                render_text(
                    &mut canvas,
                    &font,
                    &texture_creator,
                    &temp_str,
                    50,
                    30,
                    Color::WHITE,
                );
            }

            // Display message
                render_text(
                &mut canvas,
                &font,
                &texture_creator,
                "Hit space to shuffle cards",
                200,
                450,
                Color::WHITE,
            );                   
        }

        // Present the canvas
        canvas.present();

        // Limit to 60 FPS
        std::thread::sleep(Duration::new(0, 1_000_000_000u32 / 60));
    }

    Ok(())
}
