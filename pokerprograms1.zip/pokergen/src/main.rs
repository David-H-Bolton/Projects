
use std::fs::File;
use std::io::Write;
use std::hash::{BuildHasher, Hasher, RandomState};

#[derive(Debug, Clone, PartialEq)]
enum Suit {
    Hearts,
    Diamonds,
    Clubs,
    Spades,
}

#[derive(Debug, Clone, PartialEq)]
enum Rank {
    Ace,
    Two,
    Three,
    Four,
    Five,
    Six,
    Seven,
    Eight,
    Nine,
    Ten,
    Jack,
    Queen,
    King,
}

#[derive(Debug, Clone, PartialEq)]
struct Card {
    rank: Rank,
    suit: Suit,
}

impl std::fmt::Display for Card {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        let rank_str = match self.rank {
            Rank::Ace => "A",
            Rank::Two => "2",
            Rank::Three => "3",
            Rank::Four => "4",
            Rank::Five => "5",
            Rank::Six => "6",
            Rank::Seven => "7",
            Rank::Eight => "8",
            Rank::Nine => "9",
            Rank::Ten => "T",
            Rank::Jack => "J",
            Rank::Queen => "Q",
            Rank::King => "K",
        };
        
        let suit_str = match self.suit {
            Suit::Hearts => "♥",
            Suit::Diamonds => "♦",
            Suit::Clubs => "♣",
            Suit::Spades => "♠",
        };
        write!(f, "{rank_str}{suit_str}")        
    }
}

fn rand() -> u64 {
    RandomState::new().build_hasher().finish()
}

struct Deck {
    cards: Vec<Card>,
}

impl Deck {
    fn new() -> Self {
        let mut cards = Vec::with_capacity(52);
        
        for suit in [Suit::Hearts, Suit::Diamonds, Suit::Clubs, Suit::Spades].iter() {
           for rank in [
                Rank::Ace, Rank::Two, Rank::Three, Rank::Four, Rank::Five,
                Rank::Six, Rank::Seven, Rank::Eight, Rank::Nine, Rank::Ten,
                Rank::Jack, Rank::Queen, Rank::King
            ].iter() {                
                cards.push(Card {
                    rank: rank.clone(),
                    suit: suit.clone(),
                });
            }
        }
      
        Deck { cards }
    }

    fn shuffling(&mut self) {
        let n: usize = self.cards.len();
        for i in 0..(n - 1) {
            let j = (rand() as usize) % (n - i) + i;
            self.cards.swap(i, j);
        }
    }
   
    fn shuffle(&mut self) {
        for _i in 1..1000 {  
          self.shuffling();
        }
    }    

    fn first_seven(&self) ->&[Card] {
        &self.cards[..7]
}

}



fn main() -> std::io::Result<()> {
    
    let mut deck = Deck::new();

    // Create and open the output file
    let mut file = File::create("card_hands.txt")?;
    
    // Generate 1000 lines
    for _ in 0..1000 {
        // Shuffle the deck
        deck.shuffle();
        
        for card in deck.first_seven() {
            write!(file,"{card} ")?;
        }
        writeln!(file, "")?;
    }
    
    Ok(())
}