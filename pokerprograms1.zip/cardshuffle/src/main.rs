use std::time::Instant;
use std::hash::{BuildHasher, Hasher, RandomState};
use rand::seq::SliceRandom;
use rand::thread_rng;

#[derive(Debug, Clone, PartialEq)]
enum Suit {
    Hearts,
    Diamonds,
    Clubs,
    Spades,
}

#[derive(Debug, Clone, PartialEq)]
enum Rank {
    Ace,
    Two,
    Three,
    Four,
    Five,
    Six,
    Seven,
    Eight,
    Nine,
    Ten,
    Jack,
    Queen,
    King,
}

#[derive(Debug, PartialEq)]
struct Card {
    rank: Rank,
    suit: Suit,
}

struct Deck {
    cards: Vec<Card>,
}

fn rand() -> u64 {
    RandomState::new().build_hasher().finish()
}

impl Deck {
    fn new() -> Self {
        let mut cards = Vec::with_capacity(52);
        
        for suit in [Suit::Hearts, Suit::Diamonds, Suit::Clubs, Suit::Spades].iter() {
           for rank in [
                Rank::Ace, Rank::Two, Rank::Three, Rank::Four, Rank::Five,
                Rank::Six, Rank::Seven, Rank::Eight, Rank::Nine, Rank::Ten,
                Rank::Jack, Rank::Queen, Rank::King
            ].iter() {                
                cards.push(Card {
                    rank: rank.clone(),
                    suit: suit.clone(),
                });
            }
        }
      
        Deck { cards }
    }

    fn shuffling(&mut self) {
        let n: usize = self.cards.len();
        for i in 0..(n - 1) {
            let j = (rand() as usize) % (n - i) + i;
            self.cards.swap(i, j);
        }
    }

    fn shuffle1(&mut self) {
        for _i in 1..1000 {  
          self.shuffling();
        }
    }

    fn shuffle2(&mut self) {
        for _i in 1..1000 {        
        self.cards.shuffle(&mut thread_rng());
        }
    }

    fn shuffle3(&mut self) {
        let mut rng = thread_rng();
        for _i in 1..1000 {         
            self.cards.shuffle(&mut rng);
        }
    }      
    
    fn deal(&mut self) -> Option<Card> {
        self.cards.pop()
    }
    
    fn remaining(&self) -> usize {
        self.cards.len()
    }


}

impl std::fmt::Display for Card {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        let rank_str = match self.rank {
            Rank::Ace => "A",
            Rank::Two => "2",
            Rank::Three => "3",
            Rank::Four => "4",
            Rank::Five => "5",
            Rank::Six => "6",
            Rank::Seven => "7",
            Rank::Eight => "8",
            Rank::Nine => "9",
            Rank::Ten => "10",
            Rank::Jack => "J",
            Rank::Queen => "Q",
            Rank::King => "K",
        };
        
        let suit_str = match self.suit {
            Suit::Hearts => "♥",
            Suit::Diamonds => "♦",
            Suit::Clubs => "♣",
            Suit::Spades => "♠",
        };
        write!(f, "{rank_str}{suit_str}")        
    }
}

fn main() {
    // Create a new deck
    let mut deck = Deck::new();
    println!("New deck created with {} cards", deck.remaining());

    // --- Method 1 ---
    // start timing
    let start = Instant::now();  

    // Shuffle the deck
    deck.shuffle1();

    // end timing
    let duration = start.elapsed();      
    println!("1. Time elapsed in shuffling is: {:?}", duration/1000);  

    // --- Method 2 ---
    let start = Instant::now();  

    // Shuffle the deck
    deck.shuffle2();

    // end timing
    let duration = start.elapsed();      
    println!("2. Time elapsed in shuffling is: {:?}", duration/1000);        

    let start = Instant::now();  

    // Shuffle the deck
    deck.shuffle3();

    // end timing
    let duration = start.elapsed();      
    println!("3. Time elapsed in shuffling is: {:?}", duration/1000);  
    
      // Deal some cards
    println!("\nDealing 5 cards:");
    for _ in 0..5 {
        if let Some(card) = deck.deal() {
            println!("Dealt: {card}" );
        }
    }
    
    println!("\nRemaining cards: {}", deck.remaining());
  
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_new_deck_size() {
        let deck = Deck::new();
        assert_eq!(deck.remaining(), 52);
    }
    
    #[test]
    fn test_dealing_reduces_size() {
        let mut deck = Deck::new();
        deck.deal();
        assert_eq!(deck.remaining(), 51);
    }
    
    #[test]
    fn test_shuffle_maintains_size() {
        
        let mut deck = Deck::new();
        let initial_size = deck.remaining();
        deck.shuffle1();
        assert_eq!(deck.remaining(), initial_size);
      
    }
}