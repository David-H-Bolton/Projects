use std::env;
use sdl2::event::Event;
use sdl2::keyboard::Keycode;
use sdl2::mouse::MouseButton;
use sdl2::pixels::Color;
use sdl2::rect::Rect;
use sdl2::render::{Canvas, TextureCreator};
use sdl2::ttf::Font;
use sdl2::video::{Window, WindowContext};
use std::path::Path;
use std::time::Duration;
use std::hash::{BuildHasher, Hasher, RandomState};

#[derive(Debug, Clone, Copy, PartialEq)]
struct Point{
    start: i32,
    end: i32,
}
// Button structure to track state and position
struct Button {
    rect: Rect,
    text: String, // 3..8
    is_hovered: bool,
    is_clicked: bool,
}

impl Button {
    fn new(x: i32, y: i32, width: u32, height: u32, text: &str) -> Self {
        Button {
            rect: Rect::new(x, y, width, height),
            text: text.to_string(),
            is_hovered: false,
            is_clicked: false,
        }
    }

    fn is_point_inside(&self, x: i32, y: i32) -> bool {
        self.rect.contains_point((x, y))
    }

    fn render<T>(&self, canvas: &mut Canvas<Window>, font: &Font, texture_creator: &TextureCreator<T>) {
        // Draw button background
        let bg_color = if self.is_clicked {
            Color::RGB(100, 100, 200) // Darker color when clicked
        } else if self.is_hovered {
            Color::RGB(120, 120, 220) // Lighter color when hovered
        } else {
            Color::RGB(150, 150, 250) // Default color
        };
        
        canvas.set_draw_color(bg_color);
        canvas.fill_rect(self.rect).unwrap();
        
        // Draw button border
        canvas.set_draw_color(Color::RGB(50, 50, 50));
        canvas.draw_rect(self.rect).unwrap();
        
        // Render text
        let surface = font
            .render(&self.text)
            .blended(Color::RGB(255, 255, 255))
            .unwrap();
        let texture = texture_creator
            .create_texture_from_surface(&surface)
            .unwrap();
        
        // Center text in button
        let text_width = surface.width();
        let text_height = surface.height();
        let text_x = self.rect.x + ((self.rect.width() as i32 - text_width as i32) / 2);
        let text_y = self.rect.y + ((self.rect.height() as i32 - text_height as i32) / 2);
        
        canvas
            .copy(&texture, None, Rect::new(text_x, text_y, text_width, text_height))
            .unwrap();
    }
}

// Utility function to generate random number
fn rand(val : u64) -> u64 {
    RandomState::new().build_hasher().finish() % val + 1
}

// Utility function to render text
fn render_text<'a>(
    canvas: &mut Canvas<Window>,
    font: &Font<'a, 'static>,
    texture_creator: &'a TextureCreator<WindowContext>,
    text: &str,
    x: i32,
    y: i32,
    color: Color,
) {
    let surface = font.render(text).blended(color).unwrap();
    let texture = texture_creator
        .create_texture_from_surface(&surface)
        .unwrap();
    let text_rect = Rect::new(x, y, surface.width(), surface.height());
    canvas.copy(&texture, None, text_rect).unwrap();
}

// Draw a horizontal thick line
fn draw_horizontal_thick_line(canvas: &mut Canvas<Window>, x1: i32, x2: i32, y: i32,thickness:u32, color: Color) {
    canvas.set_draw_color(color);
   // Ensure y1 is the smaller value
   let (start_x, end_x) = if x1 <= x2 { (x1,x2) } else { (x2, x1) };
    
   // Calculate height properly
   let width = (end_x - start_x) as u32;
   
   // Create rectangle with specified thickness
   let r = Rect::new(start_x, y, width, thickness);
   
   // Handle potential errors instead of unwrapping
   if let Err(e) = canvas.fill_rect(r) {
       eprintln!("Error drawing rectangle: {}", e);
   }
}

// Draw a vertical thick line
fn draw_vertical_thick_line(canvas: &mut Canvas<Window>, x: i32, y1: i32, y2: i32, thickness: u32, color: Color) {
    canvas.set_draw_color(color);
    
    // Ensure y1 is the smaller value
    let (start_y, end_y) = if y1 <= y2 { (y1, y2) } else { (y2, y1) };
    
    // Calculate height properly
    let height = (end_y - start_y) as u32;
    
    // Create rectangle with specified thickness
    let r = Rect::new(x, start_y, thickness, height);
    
    // Handle potential errors instead of unwrapping
    if let Err(e) = canvas.fill_rect(r) {
        eprintln!("Error drawing rectangle: {}", e);
    }
}

// add a few random horizontal lines each start and end points
fn add_lines(num_players:i32)->Vec<Point>{
    let num_lines = num_players+2;
    let yoff = 390 / (num_players as i32 + 1);     
    let mut inity = 160;    
    let mut result = Vec::new();
    (0..num_lines).for_each(|_| {
        let mut start: i32;
        let mut end: i32;
        loop {  // Pick randomly start and end, make sure they are not the same and start < end
            start = rand(num_players as u64) as i32;
            end =  rand(num_players as u64) as i32;
            if start == end {
                continue;
            }
            if start > end {  // Make sure start < end
                let temp = start;
                start = end;
                end = temp;
            }
            break;
        }   
        inity += yoff; // Check to limit lines
        if inity >= 550 {
            return;
        }
        let p = Point{start, end};
        result.push(p); 
    });
    result
}

// draws complete path from top to bottom
// Note all lines are drawn vertically in the range from 160 to 550 
fn draw_path(canvas: &mut Canvas<Window>, lines: &Vec<Point>, mut player:i32,num_players:i32){
    let xoff = 900 / (num_players as i32 + 1);
    let yoff = 390 / (num_players as i32 + 1);     
    let inity = 160;
    let mut y1 = inity; 
    let mut y2 = inity;
    let mut drawn=false;
    lines.iter().for_each(|p| {              
        if (&player == &p.start) || (&player == &p.end) {
            drawn = true;
            let mut x1 = xoff*p.start;
            let mut x2 = xoff*p.end;
            if &player == &p.end {
                let temp = x2;
                x2 = x1;
                x1 = temp;            
                player = p.start;
            }
            else {
                player = p.end;
            }

            y2= y2+yoff;
            
            // draw vertical line to this point
            draw_vertical_thick_line(canvas, x1, y1, y2, 8,Color::RGB(255, 0, 0));
            //println!("V P={} St:{} En:{} X1:{} Y1:{} Y2:{}", player,p.start, p.end,x1,y1,y2);

            // draw horizontal line 
            draw_horizontal_thick_line(canvas, x1,x2,y2-4, 8,Color::RGB(255, 0, 0));
            //println!("H P={} St:{} En:{} x1:{} x2:{} y1:{}", player, p.start, p.end,x1,x2,y1);
            y1=y2;
            if y1 >= 550 {
                y1 = 550;
            }
        } else {
            y2 += yoff;
            if y2 >= 550 {
                y2 = 550;
            }
        }

    });
    if !drawn { // If no horizontal lines, draw a big vertical one.
        let x1 = xoff*player;
        let y2 = 550;
        draw_vertical_thick_line(canvas, x1, 160, y2, 8,Color::RGB(255, 0, 0));
        //println!("V P={} X:{} Y1:{} Y2:{}", player,x1,160,y2);   
    }
    else if y1 < 550 {  // Draw last line to bottom
        let x1 = xoff*player;
        let y2 = 550;
        draw_vertical_thick_line(canvas, x1, y1, y2, 8,Color::RGB(255, 0, 0));
        //println!("V P={} X:{} Y1:{} Y2:{}", player,x1,y1,y2);   
    }
}

fn main() -> Result<(), String> {
    // Read command line arguments
    let mut num_players = 5;
    let args: Vec<String> = env::args().collect();
    if args.len() == 2 {
        num_players = (&args[1]).parse().expect("not a number");  
        if num_players < 3 || num_players > 8   {
            eprintln!("Number of people must be between 3 and 8");
            std::process::exit(1);
        }      
    } else {
        eprintln!("Usage: cargo run <number of people>");
        eprintln!("For example: cargo run 5");
        std::process::exit(1);
    }

    // throw in a few lines
    let lines =add_lines(num_players);
    let x_player = rand(num_players as u64) as i32+1;

    // Initialize SDL2
    let sdl_context = sdl2::init()?;
    let video_subsystem = sdl_context.video()?;
    let _image_context = sdl2::image::init(sdl2::image::InitFlag::PNG)?;
    let ttf_context = sdl2::ttf::init().map_err(|e| e.to_string())?;
    
    // Create window
    let window = video_subsystem
        .window("Choice", 900, 600)
        .position_centered()
        .build()
        .map_err(|e| e.to_string())?;
    
    let mut canvas = window.into_canvas().build().map_err(|e| e.to_string())?;
    let texture_creator = canvas.texture_creator();
    
    // Load font
    let font_path = Path::new("assets/fonts/cps.ttf");
    let font_size = 24;
    let font = ttf_context.load_font(font_path, font_size)?;
    
    // Create buttons on top of vertical lines
    let mut buttons = vec![];
    let xoff = 900 / (num_players as i32 + 1);
    let mut initx = xoff-10;
    let mut draw_player: u8 = 0;
      
    // build Button list
    (1..num_players+1).for_each(|i| {
        let button=Button::new(initx, 100, 20, 50, &i.to_string());
        buttons.push(button);
        initx += xoff;
    });
    
    // Main loop
    let mut event_pump = sdl_context.event_pump()?;
    //let mut mouse_x = 0;
    //let mut mouse_y = 0;
    
    'running: loop {
        // Handle events
        for event in event_pump.poll_iter() {
            match event {
                Event::Quit { .. } | Event::KeyDown { keycode: Some(Keycode::Escape), .. } => {
                    break 'running;
                }
                Event::MouseMotion { x, y, .. } => {
                   // mouse_x = x;
                   // mouse_y = y;
                    
                    // Update button hover states
                    let mut player=1;
                    draw_player = 0;
                    buttons.iter_mut().for_each(|button| {
                        button.is_hovered = button.is_point_inside(x, y);
                        if button.is_hovered {
                            draw_player = player;
                        }
                        player += 1;
                    });
                }
                Event::MouseButtonDown { mouse_btn: MouseButton::Left, x, y, .. } => {
                    // Update button click states
                    buttons.iter_mut().for_each(|button| {
                        if button.is_point_inside(x, y) {
                            button.is_clicked = true;
                        }
                    });
                }
                Event::MouseButtonUp { mouse_btn: MouseButton::Left, .. } => {
                    // Reset button click states
                    buttons.iter_mut().for_each(|button| {
                        button.is_clicked = false;
                    });
                }
                _ => {}
            }
        }
        
        // Clear screen
        canvas.set_draw_color(Color::RGB(240, 240, 240));
        canvas.clear();
        
        let xoff = 900 / (num_players as i32 + 1);
        let yoff = 390 / (num_players as i32 + 1);
        let mut initx = xoff;
        let mut inity = 160;       
        // Draw vertical lines
        for _ in 0..num_players {
            draw_vertical_thick_line(&mut canvas, initx, inity, 550, 2,Color::RGB(0, 0, 0));
            initx += xoff;
        }
        // Draw horizontal lines starting at 160+yoff
        inity = 160 + yoff;
        let lines_copy = lines.clone();
        lines_copy.iter().for_each(|p| {
            draw_horizontal_thick_line(&mut canvas, xoff*p.start, xoff*p.end, inity, 2,Color::RGB(0, 0, 0));
            //println!("{} {} {} {} {}", p.start, p.end,xoff*p.start,xoff*p.end,inity);
            inity += yoff;
        });

       // Draw path
        if draw_player != 0 {
            draw_path(&mut canvas, &lines, draw_player as i32,num_players);
        }   

        // Render buttons
        buttons.iter().for_each(|button| {
            button.render(&mut canvas, &font, &texture_creator);
        });
        
        // Render text
        render_text(
            &mut canvas,
            &font,
            &texture_creator,
            "Members",
            400,
            30,
            Color::RGB(0, 0, 0),
        );

        // X Marks the spot
        render_text(
            &mut canvas,
            &font,
            &texture_creator,
            "X",
            xoff*x_player-5,
            555,
            Color::RGB(0, 0, 0),
        );
        
        // Display mouse coordinates for debug purposes
/*         let coords_text = format!("Mouse: ({}, {})", mouse_x, mouse_y);
        render_text(
            &mut canvas,
            &font,
            &texture_creator,
            &coords_text,
            600,
            550,
            Color::RGB(100, 100, 100),
        ); */
        
        // Present the rendered frame
        canvas.present();
        
        // Control frame rate
        //std::thread::sleep(Duration::new(0, 1_000_000_000u32 / 60));
    }
    
    Ok(())
}
