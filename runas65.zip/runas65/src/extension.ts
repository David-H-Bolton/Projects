// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
import * as vscode from 'vscode';
import * as path from 'path';

const as65Path = path.resolve(__dirname, 'D:/development/LinuxFormat/Articles/June2024/Code/as65/bin/Debug/net8.0');
const exePath= path.join(as65Path,"as65.exe");
const params ="-v -l";

// This method is called when your extension is activated
// Your extension is activated the very first time the command is executed
export function activate(context: vscode.ExtensionContext) {

	const disposable = vscode.commands.registerCommand('runas65.run6502Assembler', () => {
		const filename =vscode.window.activeTextEditor?.document.fileName;
		if (!filename) 
		   {
			vscode.window.showErrorMessage("Please open the 6502 source code file in Visual Studio Code");
			return;
		   }		
		const task = new vscode.Task(
			{type: ''},
			vscode.TaskScope.Workspace,
			"as65",
			"runas65",
			new vscode.ProcessExecution(exePath, [filename,params],
				{ cwd:as65Path}));
		vscode.tasks.executeTask(task);

		vscode.window.showInformationMessage('runas65 running!');
	});

	context.subscriptions.push(disposable);
}

// This method is called when your extension is deactivated
export function deactivate() {}


