use std::fs::File;
use std::io::{BufRead, BufReader, Read};
use uname::uname;

fn get_temperature()-> f32 {
    let mut file = File::open("/sys/class/thermal/thermal_zone0/temp").unwrap();
    let mut contents = String::new();
    file.read_to_string(&mut contents).unwrap();
    let temp: f32 = contents.trim().parse().unwrap();
    temp / 1000.0
}

fn is_pi_system() -> bool {
    let info = uname().unwrap();
    if info.nodename!="raspberrypi" {
        return false;
    }
	if info.machine!="aarch64"{
        return false;
        }
	true
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    if !is_pi_system() {
        eprintln!("Please run this on a Raspberry Pi");
        return Ok(());
    }
    let info = uname().unwrap();

    println!("{}", info.sysname);
    println!("{}", info.nodename);
    println!("{}", info.release);
    println!("{}", info.version);
    println!("{}", info.machine);
    println!("Temperature: {:.2}°C", get_temperature());
    // get the cpu model 
    let file = File::open("/proc/cpuinfo").expect("Unable to read /proc/cpuinfo");
    let reader = BufReader::new(file);

    // Read the file line by line and print its contents   
    for line in reader.lines() {
        let line = line?;
        if line.to_lowercase().contains("model") {
            println!("{}", line);
        }
    }
    Ok(())
}
