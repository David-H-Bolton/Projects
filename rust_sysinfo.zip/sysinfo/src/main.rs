use std::{fs::File, io::Read};
use uname::uname;

fn get_temperature()-> f32 {
    let mut file = File::open("/sys/class/thermal/thermal_zone0/temp").unwrap();
    let mut contents = String::new();
    file.read_to_string(&mut contents).unwrap();
    let temp: f32 = contents.trim().parse().unwrap();
    temp / 1000.0
}

fn is_pi_system() -> bool {
    let info = uname().unwrap();
    if info.nodename!="raspberrypi" {
        return false;
    }
	if info.machine!="aarch64"{
        return false;
        }
	true
}

fn main() {
    if !is_pi_system() {
        eprintln!("Please run this on a Raspberry Pi");
        return;
    }
    let info = uname().unwrap();

    println!("{}", info.sysname);
    println!("{}", info.nodename);
    println!("{}", info.release);
    println!("{}", info.version);
    println!("{}", info.machine);
    println!("Temperature: {:.2}°C", get_temperature());
}
