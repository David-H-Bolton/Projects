// (C) 2023 LinuxFormat. Author David Bolton
// r key restart, f / s speed up delay or slow it.

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <SDL2/SDL.h>
#include <stdbool.h>
#include <sys/utsname.h>

// define the screen
#define WIDTH 800
#define HEIGHT 800

// define how big the maze is
#define row 80
#define col 80


// define all the states a cell can have
enum CellState { visited, wall, unvisited };
enum SolutionState { unmarked, marked, solved };

enum CellState maze[row][col];
enum SolutionState solution[row][col];

// directions        N        W       S       E
int dir[4][2] = { {0, -2}, {-2, 0}, {0, 2}, {2, 0} };

// variables
SDL_Rect wallRect = { .w = (WIDTH / col), .h = (HEIGHT / row) };
SDL_Renderer* renderer;
SDL_Window* window;
char message[100];
bool restartFlag = false;
bool showTemp = false;
bool debugFlag = false;
int delayTime = 10; // MS delay while drawing/solving map. Speed up with f key or slower with s key
bool piFlag;
float lastTemp;
int tempCount;

// Only call if running on a RaspI. Checks piFlag
float ReadPiTemperature() {
    char buffer[10];
    char* end;
    if (!piFlag) return 0.0f;
    if (SDL_GetTicks() - tempCount < 1000) {
        return lastTemp;
    }
    tempCount = SDL_GetTicks();
    FILE* temp = fopen("/sys/class/thermal/thermal_zone0/temp", "rt");
    int numread = fread(buffer, 10, 1, temp);
    fclose(temp);
    lastTemp = strtol(buffer, &end, 10) / 1000.0f;
    return lastTemp;
}

// Sets Window caption 
void SetWindowCaption() {
    strcpy(message, "Maze");
    if (debugFlag) {
        if (piFlag) {
            float temperature = ReadPiTemperature();
            sprintf(message, "Maze Delay=%d Temperature = %3.2f C", delayTime, temperature);
        }
        else {
            sprintf(message, "Maze Delay=%d", delayTime);
        }
    }
    SDL_SetWindowTitle(window, message);
}

// detects if running on a raspberry Pi and sets piFlag accordingly
void SetPiFlag() {
    piFlag = false;
    struct utsname buffer;
    if (uname(&buffer) != 0) return;
    if (strcmp(buffer.nodename, "raspberrypi") != 0) return;
    if (strcmp(buffer.machine, "armv7l") == 0 && 
        strcmp(buffer.machine, "aarch64") == 0) return;
    piFlag = true;
}

// Handles keyboard input. If loop parameter is true then it sits
// in a loop waiting for escape to be pressed or mouse click on the close button
// Otherwise it drops out immediately
void HandleInput(bool loop) {
    SDL_Event event;
    int keypressed = 0;
    bool finished = false;
    while (!finished) {
        if (SDL_PollEvent(&event)) {
            switch (event.type) {
            case SDL_KEYDOWN:
                keypressed = event.key.keysym.sym;
                switch (keypressed) {
                case SDLK_ESCAPE:
                {
                    finished = true;
                    break;
                }
                case SDLK_f: // faster
                {
                    if (delayTime > 0) {
                        delayTime -= 5; 
                        if (delayTime <0){ // Minimum is 0 delay
                            delayTime =0;
                        }
                    }
                    SetWindowCaption();
                    break;
                }
                case SDLK_s: // slower
                {
                    if (delayTime < 50) delayTime += 5; // max 50
                    SetWindowCaption();
                    break;
                }
                case SDLK_r: // restart but only at end
                    if (loop) {
                        restartFlag = true;
                        finished = true;
                        break;
                    }
                case SDLK_TAB: // Toggle debug
                    debugFlag = !debugFlag;
                    SetWindowCaption();
                } // switch (keypressed)
            case SDL_QUIT: /* if mouse click to close window */
            {
                finished = true;
                break;
            }
            case SDL_KEYUP: {
                break;
            } /* switch */
            }

        } // if       
        if (!loop) break;
    }// while  
}

// Draw the maze using SDL
void DrawMaze() {
    // Set background to white
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);  // white
    SDL_RenderClear(renderer);

    // draw walls in black
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);  // black
    for (int r = 0; r < row; ++r) {
        for (int c = 0; c < col; ++c) {
            if (maze[r][c] == wall) {
                wallRect.x = c * wallRect.w;
                wallRect.y = r * wallRect.h;
                SDL_RenderFillRect(renderer, &wallRect);
            }
        }
    }
    // Draw solution path in red
    SDL_SetRenderDrawColor(renderer, 255, 0, 0, 0);  // red
    for (int r = 0; r < row; ++r) {
        for (int c = 0; c < col; ++c) {
            if (solution[r][c] == solved) {
                wallRect.x = c * wallRect.w + 1;
                wallRect.y = r * wallRect.h + 1;
                wallRect.w -= 2; // Shrink rect by 2 before drawing 
                wallRect.h -= 2;
                SDL_RenderFillRect(renderer, &wallRect);
                wallRect.w += 2; // And restore 
                wallRect.h += 2;
            }
        }
    }
    // Flips the screen to show it
    SDL_RenderPresent(renderer); // flip screen
    SDL_Delay(delayTime);
    SetWindowCaption();
    HandleInput(false); // false means don't wait in a loop
}

// picks a direction where it hasn't been
int pickDirection(int r, int c) {
    // make a list of all the unvisited neighbours
    int list[4] = { 0 };
    int count = 0;
    if (r >= 2 && maze[r - 2][c] == unvisited) {
        list[count++] = 1;
    }
    if (r < row - 2 && maze[r + 2][c] == unvisited) {
        list[count++] = 3;
    }
    if (c >= 2 && maze[r][c - 2] == unvisited) {
        list[count++] = 0;
    }
    if (c < col - 2 && maze[r][c + 2] == unvisited) {
        list[count++] = 2;
    }
    if (count)
        return list[rand() % count];
    return -1;
}

// creates a maze
void createMaze(int r, int c) {
    // mark the cell as visited
    maze[r][c] = visited;
    if (r == 0 && c == 0) {
        maze[row - 1][col - 2] = visited; // endpoint
    }
    while (true) {
        int direction = pickDirection(r, c);
        if (direction == -1) return;
        int newr = r + dir[direction][0];
        int newc = c + dir[direction][1];
        maze[(r + newr) / 2][(c + newc) / 2] = visited;
        DrawMaze();
        createMaze(newr, newc);
    }
}

// Solves the maze
int solveMaze(int r, int c) {
    if (r == row - 1 && c == col - 2) { // Set end point
        solution[r][c] = solved;
        return 1;
    }
    solution[r][c] = marked;

    // go NORTH?
    if (r - 1 >= 0 && maze[r - 1][c] != wall && solution[r - 1][c] == unmarked) {
        if (solveMaze(r - 1, c)) {
            solution[r][c] = solved;
            DrawMaze();
            return 1;
        }
    }

    // go WEST?
    if (c + 1 < col && maze[r][c + 1] != wall && solution[r][c + 1] == unmarked) {
        if (solveMaze(r, c + 1)) {
            solution[r][c] = solved;
            DrawMaze();
            return 1;
        }
    }

    // go SOUTH?
    if (r + 1 < row && maze[r + 1][c] != wall && solution[r + 1][c] == unmarked) {
        if (solveMaze(r + 1, c)) {
            solution[r][c] = solved;
            DrawMaze();
            return 1;
        }
    }

    // go EAST?
    if (c - 1 >= 0 && maze[r][c - 1] != wall && solution[r][c - 1] == unmarked) {
        if (solveMaze(r, c - 1)) {
            solution[r][c] = solved;
            DrawMaze();
            return 1;
        }
    }

    solution[r][c] = unmarked;
    return 0;
}

//  Initializes maze and solution arrays
void InitializeMaze()
{
    for (int r = 0; r < row; ++r) {
        for (int c = 0; c < col; ++c) {
            solution[r][c] = unmarked;
            maze[r][c] = unvisited;
            if (r % 2 || c % 2) maze[r][c] = wall;
        }
    }
}

int main(int arcg, char* args[]) {
    SDL_Init(SDL_INIT_EVERYTHING);

    window = SDL_CreateWindow(
        "Maze", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WIDTH, HEIGHT,
        SDL_WINDOW_SHOWN
    );

    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | 
      SDL_RENDERER_PRESENTVSYNC);
 
    srand((unsigned int)time(0));
    tempCount = SDL_GetTicks();
    SetPiFlag();

    do {
        restartFlag = false;
        InitializeMaze();
        createMaze(0, 0);
        solveMaze(0, 0);
        DrawMaze();
        HandleInput(true);
    } while (restartFlag);

    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
