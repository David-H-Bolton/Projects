use std::collections::{HashMap, HashSet};
use std::env;
use std::fmt;
use std::fs::File;
use std::io::{self, BufRead};
use std::time::Instant;

#[derive(Debug, PartialEq, Eq, Hash, Clone, Copy)]
enum Suit {
    Hearts,
    Diamonds,
    Clubs,
    Spades,
}

#[derive(Debug, PartialEq, Eq, Hash, Clone, Copy)]
enum Rank {
    Two,
    Three,
    Four,
    Five,
    Six,
    Seven,
    Eight,
    Nine,
    Ten,
    Jack,
    Queen,
    King,
    Ace,
}

impl Rank {
    fn value(&self) -> u8 {
        match self {
            Rank::Two => 2,
            Rank::Three => 3,
            Rank::Four => 4,
            Rank::Five => 5,
            Rank::Six => 6,
            Rank::Seven => 7,
            Rank::Eight => 8,
            Rank::Nine => 9,
            Rank::Ten => 10,
            Rank::Jack => 11,
            Rank::Queen => 12,
            Rank::King => 13,
            Rank::Ace => 14,
        }
    }

    fn from_str(c: &char) -> Option<Rank> {
        match c {
            '2' => Some(Rank::Two),
            '3' => Some(Rank::Three),
            '4' => Some(Rank::Four),
            '5' => Some(Rank::Five),
            '6' => Some(Rank::Six),
            '7' => Some(Rank::Seven),
            '8' => Some(Rank::Eight),
            '9' => Some(Rank::Nine),
            'T' => Some(Rank::Ten),
            'J' => Some(Rank::Jack),
            'Q' => Some(Rank::Queen),
            'K' => Some(Rank::King),
            'A' => Some(Rank::Ace),
            _ => None,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
struct Card {
    suit: Suit,
    rank: Rank,
}

impl Card {
    fn from_str(s: &str) -> Option<Card> {
        let chars: Vec<char> = s.chars().collect();
        if s.len() != 2 {
            return None;
        }

        let suit = match chars[1] {
            'H' => Suit::Hearts,
            'D' => Suit::Diamonds,
            'C' => Suit::Clubs,
            'S' => Suit::Spades,
            _ => return None,
        };

        let rank = Rank::from_str(&chars[0])?;

        Some(Card { suit, rank })
    }
}

#[derive(Debug, PartialEq, Eq, Hash, Clone, Copy)]
enum HandRank {
    HighCard,
    OnePair,
    TwoPair,
    ThreeOfAKind,
    Straight,
    Flush,
    FullHouse,
    FourOfAKind,
    StraightFlush,
}

impl fmt::Display for HandRank {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let hand_rank_str = match self {
            HandRank::HighCard => "High Card",
            HandRank::OnePair => "One Pair",
            HandRank::TwoPair => "Two Pair",
            HandRank::ThreeOfAKind => "Three of a Kind",
            HandRank::Straight => "Straight",
            HandRank::Flush => "Flush",
            HandRank::FullHouse => "Full House",
            HandRank::FourOfAKind => "Four of a Kind",
            HandRank::StraightFlush => "Straight Flush",
        };
        write!(f, "{}", hand_rank_str)
    }
}

fn find_best_hand(cards: &mut [Card]) -> HandRank {
    let mut rank_counts = HashMap::new();
    for card in cards.iter() {
        *rank_counts.entry(card.rank).or_insert(0) += 1;
    }

    let mut has_three = false;
    let mut has_two = 0;
    let mut has_four = false;

    for &count in rank_counts.values() {
        match count {
            2 => has_two += 1,
            3 => has_three = true,
            4 => {
                has_four = true;
                has_three = false;
            }
            _ => (),
        }
    }

    let mut is_straight = false;
    let mut is_flush = false;

    // check if a Flush
    let mut suit_counts = HashMap::new();
    for card in cards.iter() {
        *suit_counts.entry(card.suit).or_insert(0) += 1;
    }   

    for &count in suit_counts.values() {
        if count >= 5 {
            is_flush = true;
            break;
        }
    }

    // check if a straight
    let mut values: HashSet<u8> = cards.iter().map(|card| card.rank.value()).collect();
    let mut unique_values: Vec<u8> = values.drain().collect();
    unique_values.sort_unstable();

    let mut straight_length = 1;
    for i in 1..unique_values.len() {
        if unique_values[i] == unique_values[i - 1] + 1 {
            straight_length += 1;
            if straight_length == 5 {
                is_straight = true;
                break;
            }
        } else {
            straight_length = 1;
        }
    }

    // Check for A2345 straight
    if unique_values.contains(&Rank::Ace.value())
        && unique_values[..4]
            == [
                Rank::Two.value(),
                Rank::Three.value(),
                Rank::Four.value(),
                Rank::Five.value(),
            ]
    {
        is_straight = true;
    }


    if is_straight && is_flush {
        return HandRank::StraightFlush;
    }

    if is_straight {
        return HandRank::Straight;
    }

    if is_flush {
        return HandRank::Flush;
    }

    if has_two == 1 {   // Could be a full house or just a pair
        if has_three {
            return HandRank::FullHouse;
        }
        return HandRank::OnePair;
    } else if has_two > 1 {
        return HandRank::TwoPair;
    } else if has_three {
        return HandRank::ThreeOfAKind;
    } else if has_four {
        return HandRank::FourOfAKind;
    }

    HandRank::HighCard
}

fn read_hands_from_file(filename: &str) -> io::Result<Vec<Vec<Card>>> {
    let mut hands = Vec::new();
    let file = File::open(filename)?;
    let reader = io::BufReader::new(file);

    for line in reader.lines() {
        match line {
            Ok(mut content) => {
                if show_cards() {
                    println!("{content}");
                }
                if content.len() > 21 {
                    content.truncate(21);
                }

                let cards: Vec<&str> = content.split_whitespace().collect();
                let mut hand: Vec<Card> = Vec::new();

                for card_str in cards {
                    if let Some(card) = Card::from_str(card_str) {
                        hand.push(card);
                    };
                }
                hands.push(hand);
            }

            Err(e) => eprintln!("Error readlinf line {e}"),
        }
    }
    Ok(hands)
}

fn show_cards() -> bool {
    cfg!(feature = "show_cards")
}

fn main() -> io::Result<()> {
    let args: Vec<String> = env::args().collect();
    if args.len() != 2 {
        eprintln!("Missing file parameter");
        return Err(io::Error::last_os_error());
    }
    let filename = &args[1];
    let hands = read_hands_from_file(&filename)?;

    if hands.len() > 0 {
        let start = Instant::now();
        for hand in hands {
            let best_hand = find_best_hand(&mut hand.clone());

            if show_cards() {
                println!("Best hand: {}", best_hand);
            }
        }
        let duration = start.elapsed();
        if !show_cards() {
            println!("Time per hand: {:?}", duration / 1000);
        }
    } else {
        eprintln!("No hands were read from {filename}");
    }
    Ok(())
}
