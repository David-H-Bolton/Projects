use sdl2::controller::Button;
use sdl2::event::Event;
use sdl2::image::{self, InitFlag};
use sdl2::keyboard::Keycode;
use sdl2::pixels::Color;
use sdl2::rect::Rect;
use sdl2::render::{Canvas, TextureCreator, TextureQuery};
use sdl2::video::{Window, WindowContext};
use std::collections::HashMap;
use std::time::Duration;
use std::fs;
use std::io::{self, Read};
use std::path::Path;

const WINDOW_WIDTH: u32 = 800;
const WINDOW_HEIGHT: u32 = 600;
const FONT_SIZE: u16 = 24;

fn read_file_to_string<P: AsRef<Path>>(file_path: P) -> io::Result<String> {
    // Open the file
    let mut file = fs::File::open(file_path)?;
    
    // Create a string to store the content
    let mut content = String::new();
    
    // Read the file content into the string
    file.read_to_string(&mut content)?;
    
    // Return the string
    Ok(content)
}

fn main() -> Result<(), String> {
    let sdl_context = sdl2::init()?;
    let video_subsystem = sdl_context.video()?;
    let controller_subsystem = sdl_context.game_controller()?;
    
    // Initialize SDL2_image
    let _image_context = image::init(InitFlag::PNG | InitFlag::JPG)?;
    
    // Initialize SDL2_ttf
    let ttf_context = sdl2::ttf::init().map_err(|e| e.to_string())?;
    
    let window = video_subsystem
        .window("Controller Input Display", WINDOW_WIDTH, WINDOW_HEIGHT)
        .position_centered()
        .build()
        .map_err(|e| e.to_string())?;
    
    let mut canvas = window.into_canvas().build().map_err(|e| e.to_string())?;
    let texture_creator = canvas.texture_creator();
    
    // Load a font
    let font = ttf_context.load_font("./assets/fonts/cps.ttf", FONT_SIZE)?;

    // Set up controller mapping if provided
    let controller_mapping = read_file_to_string("gamepad.txt").expect("Failed to load gamepad.txt");
    if controller_mapping.len() >0 {
        let _= sdl_context.game_controller()?.add_mapping(&controller_mapping).expect("Mapping failed to add");              
    }
    
    // Get available controllers
    let available = controller_subsystem.num_joysticks().map_err(|e| e.to_string())?;
    let mut available_controllers = Vec::new();
    
    for id in 0..available {
        if controller_subsystem.is_game_controller(id) {
            available_controllers.push(id);
        }
    }
    
    if available_controllers.is_empty() {
        println!("No game controllers available");
        render_message(&mut canvas, &texture_creator, &font, "No controllers detected. Please connect a controller.")?;
        wait_for_event(&sdl_context)?;
        return Ok(());
    }
    
    // Open the first available controller
    let controller_id = available_controllers[0];
    let controller = controller_subsystem.open(controller_id).map_err(|e| e.to_string())?;
    
    let controller_name = controller.name();
    println!("Using controller: {}", controller_name);
    render_message(&mut canvas, &texture_creator, &font, &format!("Controller connected: {}", controller_name))?;
    
    // Create a mapping for button names
    let button_names = create_button_names();
    
    // Track button states
    let mut button_states: HashMap<Button, bool> = HashMap::new();
    for &button in button_names.keys() {
        button_states.insert(button, false);
    }
    
    let mut event_pump = sdl_context.event_pump()?;
    'running: loop {
        for event in event_pump.poll_iter() {
            match event {
                Event::Quit { .. } | Event::KeyDown { keycode: Some(Keycode::Escape), .. } => {
                    break 'running;
                },
                Event::ControllerButtonDown { button, .. } => {
                    button_states.insert(button, true);
                },
                Event::ControllerButtonUp { button, .. } => {
                    button_states.insert(button, false);
                },
                Event::ControllerDeviceRemoved { .. } => {
                    render_message(&mut canvas, &texture_creator, &font, "Controller disconnected")?;
                    wait_for_event(&sdl_context)?;
                    break 'running;
                },
                _ => {},
            }
        }
        
        // Clear the screen
        canvas.set_draw_color(Color::RGB(0, 0, 0));
        canvas.clear();
        
        // Display controller information and button states
        let mut y_position = 50;
        
        // Render controller name
        render_text(&mut canvas, &texture_creator, &font, &format!("Controller: {}", controller_name), 20, y_position)?;
        y_position += 40;
        
        // Render buttons state
        render_text(&mut canvas, &texture_creator, &font, "Button States:", 20, y_position)?;
        y_position += 40;
        
        for (&button, &pressed) in &button_states {
            if let Some(button_name) = button_names.get(&button) {
                let state_text = if pressed { "PRESSED" } else { "Released" };
                let color = if pressed { Color::RGB(0, 255, 0) } else { Color::RGB(200, 200, 200) };
                
                render_text_with_color(
                    &mut canvas, 
                    &texture_creator, 
                    &font, 
                    &format!("{}: {}", button_name, state_text), 
                    40, 
                    y_position, 
                    color
                )?;
                
                y_position += 30;
            }
        }
        
        // Render axis values
        y_position += 20;
        render_text(&mut canvas, &texture_creator, &font, "Axis Values:", 20, y_position)?;
        y_position += 40;
        
        let axes = [
            (sdl2::controller::Axis::LeftX, "Left Stick X"),
            (sdl2::controller::Axis::LeftY, "Left Stick Y"),
            (sdl2::controller::Axis::RightX, "Right Stick X"),
            (sdl2::controller::Axis::RightY, "Right Stick Y"),
            (sdl2::controller::Axis::TriggerLeft, "Left Trigger"),
            (sdl2::controller::Axis::TriggerRight, "Right Trigger"),
        ];
        
        for (axis, name) in axes.iter() {
            let value = controller.axis(*axis);
            let normalized = value as f32 / 32768.0;
            render_text(
                &mut canvas,
                &texture_creator,
                &font,
                &format!("{}: {:.2}", name, normalized),
                40,
                y_position
            )?;
            y_position += 30;
        }
        
        canvas.present();
        std::thread::sleep(Duration::from_millis(16)); // ~60 FPS
    }
    
    Ok(())
}

fn create_button_names() -> HashMap<Button, &'static str> {
    let mut button_names = HashMap::new();
    button_names.insert(Button::A, "A");
    button_names.insert(Button::B, "B");
    button_names.insert(Button::X, "X");
    button_names.insert(Button::Y, "Y");
    button_names.insert(Button::Back, "Back");
    button_names.insert(Button::Guide, "Guide");
    button_names.insert(Button::Start, "Start");
    button_names.insert(Button::LeftStick, "Left Stick");
    button_names.insert(Button::RightStick, "Right Stick");
    button_names.insert(Button::LeftShoulder, "Left Shoulder");
    button_names.insert(Button::RightShoulder, "Right Shoulder");
    button_names.insert(Button::DPadUp, "D-Pad Up");
    button_names.insert(Button::DPadDown, "D-Pad Down");
    button_names.insert(Button::DPadLeft, "D-Pad Left");
    button_names.insert(Button::DPadRight, "D-Pad Right");
    button_names
}

fn render_message(
    canvas: &mut Canvas<Window>,
    texture_creator: &TextureCreator<WindowContext>,
    font: &sdl2::ttf::Font,
    message: &str,
) -> Result<(), String> {
    canvas.set_draw_color(Color::RGB(0, 0, 0));
    canvas.clear();
    
    render_text_centered(canvas, texture_creator, font, message, WINDOW_HEIGHT / 2)?;
    
    canvas.present();
    Ok(())
}

fn render_text(
    canvas: &mut Canvas<Window>,
    texture_creator: &TextureCreator<WindowContext>,
    font: &sdl2::ttf::Font,
    text: &str,
    x: i32,
    y: i32,
) -> Result<(), String> {
    render_text_with_color(canvas, texture_creator, font, text, x, y, Color::RGB(255, 255, 255))
}

fn render_text_with_color(
    canvas: &mut Canvas<Window>,
    texture_creator: &TextureCreator<WindowContext>,
    font: &sdl2::ttf::Font,
    text: &str,
    x: i32,
    y: i32,
    color: Color,
) -> Result<(), String> {
    let surface = font
        .render(text)
        .blended(color)
        .map_err(|e| e.to_string())?;
    
    let texture = texture_creator
        .create_texture_from_surface(&surface)
        .map_err(|e| e.to_string())?;
    
        let TextureQuery{width,height, .. } = texture.query();
    
    canvas.copy(&texture, None, Some(Rect::new(x, y, width, height)))?;
    
    Ok(())
}

fn render_text_centered(
    canvas: &mut Canvas<Window>,
    texture_creator: &TextureCreator<WindowContext>,
    font: &sdl2::ttf::Font,
    text: &str,
    y: u32,
) -> Result<(), String> {
    let surface = font
        .render(text)
        .blended(Color::RGB(255, 255, 255))
        .map_err(|e| e.to_string())?;
    
    let texture = texture_creator
        .create_texture_from_surface(&surface)
        .map_err(|e| e.to_string())?;
    
        let TextureQuery{width,height, .. } = texture.query();
    
    let x = (WINDOW_WIDTH - width) / 2;
    
    canvas.copy(&texture, None, Some(Rect::new(x as i32, y as i32, width, height)))?;
    
    Ok(())
}

fn wait_for_event(sdl_context: &sdl2::Sdl) -> Result<(), String> {
    let mut event_pump = sdl_context.event_pump()?;
    'waiting: loop {
        while let Some(event) = event_pump.wait_event_timeout(100) {
            match event {
                Event::Quit { .. } 
                | Event::KeyDown { .. }
                | Event::ControllerDeviceAdded { .. } => break 'waiting,
                _ => {},
            }
        }
    }
    Ok(())
}