<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  include "g.php";  
  $c= new Captcha(array(""));  
  $answer = strtolower(trim($_POST['answer']));
  if (empty($answer)) {
    echo "No answer provided";
  } else {
	  $correct=trim($_POST['correct']); 
	  if ($c->hashed($answer)== $correct){
		  echo "You got it right!";
	  }
	  else {
		  echo "You got it wrong.";
	  }
  }
}
?>
