﻿namespace as65
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("as65 6502 Assembler. Author D. Bolton");
            var assembler = new Assembler();
            assembler.Run(args);
        }
    }
}
