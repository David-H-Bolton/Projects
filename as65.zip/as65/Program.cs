﻿namespace as65
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("6503 Assembler");
            var assembler = new Assembler();
            assembler.Run(args);
        }
    }
}
