﻿/*
 Note. This code is not fully tested and will be updated over the next few days (18/7/2024).  

 Some conventions
  * Several methods return tuples, typically two values e.g. (AddressMode,int) GetAddressMode(string rest)
  * Everything is checked in lower case. You can write code in upper or lower case but it's converted to lower case
    before doing string/char comparisons.
 
 */



namespace as65
{
    internal class Label
    {
        public int Address { get; set; } = -1;
        public bool IsPageZero { get; set; } = false;
        public string Name { get; set; } = "";
        public bool Evaluated { get; set; } = false;
    }

    internal class Labels //Note, labels are always stored in lowercase
    {
        Dictionary<string, Label> labels = new Dictionary<string, Label>();
        internal List<string> Errors {  get; set; }= new List<string>();
        internal int Pass { get; set; }   // Needed for error checking

        internal void Add(string name, int value, bool isPageZero = false)
        {
            if (labels.Keys.Contains(name))
            {
                return;
            }
            labels.Add(name.ToLower(), new Label() { Address = value, Name = name, IsPageZero = isPageZero });
        }


        internal int GetValue(string name)
        {
            if (labels.ContainsKey(name.ToLower()))
            {
                var label = labels[name];
                if (label.Evaluated) {  
                    return label.Address; 
                }
                if (Pass==2)
                {
                    Errors.Add($"Label {name} has not been assigned a value");
                    return 0;
                }
            }
            return 0;
        }

        internal void SetValue(string name,int value,bool isPageZero)
        {
            if (!labels.ContainsKey(name.ToLower()))
            {
                Add(name,value, isPageZero);
            }
            var label = labels[name];
            label.Address = value;
            label.Evaluated = true;
            label.IsPageZero = isPageZero;
        }
    }
    internal class Assembler
    {
        [Flags]internal enum AddressMode {amUnassigned=0,amZeroPageX=1, amZeroPage=2,amImmediate=4,amAbsolute=8, amIndirectY=16,amIndirectX=32, 
                             amAbsoluteY=64,amAbsoluteX=128,amIndirect=256,amBranch=512,amZeroPageY=1024,amAccumulator=2048 };
        List<string> Errors = new List<string>();
        List<string> Lines = new List<string>();
        Opcodes opcodes = new Opcodes();
        Labels labels= new Labels();
        string filename = "";
        int CurrentIndex = 0; 
 
        int pass = 0;
        int PC = 0;
        AddressMode mode = AddressMode.amUnassigned;
        bool PageZeroValue = false;

        internal void Run(string[] args)
        {
            labels.Errors = Errors;
            var parms = new Parameters(args);
            filename = parms.Filename;
            Lines = ReadSourceFile(filename);
            if (Lines.Count==0)
            {
                Errors.Add($"No lines read from file {filename}");
                return;
            }
            if (AssembleSource(1))
            {
                var result = AssembleSource(2);
            }
        }

        // Call this to do each pass
        private bool AssembleSource(int _pass)
        {
            pass = _pass;
            if (Lines.Count == 0)
            {
                Errors.Add($"Source File {filename} is empty");
                return false;
            }
            CurrentIndex = 0;
            foreach (var line in Lines)
            {
                ProcessLine(line);
                CurrentIndex++;
            }
            return (Errors.Count == 0);
        }

        // return true if line starts with space or tab so not a label
        private bool StartsWithSpace(ref string line)
        {
            return line.StartsWith(" ") || line.StartsWith("\\t");
        }

        private void ProcessLine(string line)
        {
            if (line.StartsWith("*="))
            {
                if (line.Length==2)
                {
                    Errors.Add("Missing program counter value");
                    return;
                }
                line = line.Substring(2);
                SetProgramCounter(line);
                return;
            }
            if (StartsWithSpace(ref line))
            {
                {
                    ProcessCode(ref line);
                    return;
                }
            }
            if (StartsWithLabel(ref line))
            {
                if (!string.IsNullOrEmpty(line) && char.IsLetter(line[0]))
                {
                    var label = ExtractLabel(ref line);
                    var pc = PC;
                    if (!string.IsNullOrEmpty(line)) // Is there an instruction or comment
                    {
                        ProcessCode(ref line);
                        return;
                    }

                }
            }
            else if (StartsWithHash(line)) { 
                var gap = line.IndexOf(' ');
                if (gap > -1)
                {
                    var filename = line.Substring(gap + 1).Trim();
                    IncludeFile(filename);
                    // Delete Line after included
                }
            }
    
        }

        // Includes the specified file into List<string> Lines
        private void IncludeFile(string _filename)
        {
            var newlines = ReadSourceFile(_filename);
            if (newlines.Count > 0)
            {
                Lines.InsertRange(CurrentIndex, newlines);               
            }
        }

        // returns true if first var ==# and long enough for #includes
        private bool StartsWithHash(string line)
        {
            if (line== null) return false;
            if (line[0] == '#' && line.Length > 9) return true;
            return false;   
        }

        // Extracts and returns label, extracts rest of line
        private string ExtractLabel(ref string line)
        {
            var pos = 1;
            while (pos < line.Length)
            {
                var c = line[pos];
                if (char.IsAsciiLetterOrDigit(c))
                {
                    pos++;
                }
                else if (c == ':')
                {  // Hit end of label
                    pos++;
                    break;
                }
                else break; 
            }
            var label = line.Substring(0, pos-1);
            line = line.Substring(pos); // Leave rest of line to be processed            
            return label;

        }

        // returns true if label starts with A..Z or a..z
        private bool StartsWithLabel(ref string line)
        {
            if (line == null) return false;
            var line2=line.ToLower();
            return (line2[0] >= 'a' && line2[0] <= 'z');
        }

        // Deals with normal lines 
        private void ProcessCode(ref string line)
        {
            if (line.Contains(";"))
            {
                var pos = line.IndexOf(";");
                line = line.Substring(0, pos - 1); // Drop comment
            }
            line = line.Trim();
            if (line.Length > 0)
            {
                ProcessInstruction(ref line);
            }

        }

        // Extract then look up 6502 instructions and compiler directives
        private void ProcessInstruction(ref string line)
        {
            var code = "";
            var rest = "";
            if (line.Length == 3)
            {
                code = line;
            }
            else if (line.Length >3)
            {
                rest = line.Substring(4).Trim();
                code = rest.Substring(0, 3).Trim();
            }

            Console.WriteLine($"{PC} {code} {rest}");
            var opcode = opcodes.GetOpcode(code);
            if (opcode==null)
            {
                Errors.Add($"Opcode {code} not recognised.");
                return;
            }
            if (opcode.SingleByte)
            {
                PC++;
                if (rest!= "")
                {
                    Errors.Add($"Unknown text: {rest} following instruction");
                    return;
                }
            }
            else
            {
                var (addressMode,value) = GetAddressMode(rest);
                if (addressMode == AddressMode.amUnassigned)
                {
                    return;
                }
                if ((opcode.Modes & (uint)addressMode)== 0) // Is not a valid address mode
                {
                    Errors.Add($"Opcode {opcode} is not consistent with address mode {addressMode}");
                    return;
                }
                PC += (PageZeroValue ? 2 : 3);
                if (pass == 2)
                {
                    OutputCode(opcode,addressMode,value);
                    // Emit code
                }
            }
        }

        // Works out what opcode should be
        private void OutputCode(Opcode opcode, AddressMode addressMode,int value=0)
        {
            var rawOpcode = opcode.Value;
            if (opcode.IsBranch)
            {

            }
        }

        // determines address mode and returns it and the value, also sets ZeroPageValue accordingly
        private (AddressMode,int) GetAddressMode(string rest,bool isBranch=false)
        {
            var value = 0;
            rest = rest.ToLower().Trim();
            if (rest.Length == 0) {
                Errors.Add($"Missing address mode etc after opcode");
                return (AddressMode.amUnassigned,0); 
            }
            var ch = rest[0];
            if (ch == '#')
            {
                (value, PageZeroValue) = EvaluateExpression(rest);
                if (value>256)
                {
                    Errors.Add($"Value is immediate mode must be byte sized");
                    return (AddressMode.amUnassigned, 0);
                }
                return (AddressMode.amImmediate,value);
            }
            else
                if (ch == '$' || (ch >= '0' && ch <= '9') || (ch >= 'a' && ch < 'z'))
            { // Could be any Zeropage or absolute
                var endpos = rest.IndexOf(',');
                if (endpos == -1) // Not ,y or .x
                {
                    (value, PageZeroValue) = EvaluateExpression(rest);
                    return (PageZeroValue ? AddressMode.amZeroPage : AddressMode.amAbsolute,value);
                }
                else
                {   // abs,x or ,y or zeropage,x or ,y
                    var commaLetter = rest.Substring(endpos + 1).Trim();
                    rest = rest.Substring(0, endpos - 1);
                    (value, PageZeroValue) = EvaluateExpression(rest);
                    if (commaLetter == null || commaLetter.Length == 0)
                    {
                        Errors.Add("Missing X or Y after ,");
                        return (AddressMode.amUnassigned,0);
                    }
                    if (commaLetter.ToLower()[0] == 'x')
                    {
                        return (PageZeroValue ? AddressMode.amZeroPageX : AddressMode.amAbsoluteX,value);
                    }
                    if (commaLetter.ToLower()[0] == 'y')
                    {
                        return (PageZeroValue ? AddressMode.amZeroPageY : AddressMode.amAbsoluteY,value);
                    }
                }
            }
            else if (ch == '(')
            { // (indirect), (indirect,X) or (indirect),y
                if (rest.Length == 1)
                {
                    Errors.Add("Missing text after (");
                    return (AddressMode.amUnassigned,0);
                }
                ch = rest[1];
                if (ch == '$' || (ch > '0' && ch <= '9') || (ch >= 'a' && ch < 'z'))
                { // Could be any Zeropage or absolute
                    var endpos = rest.IndexOf(',');
                    if (endpos == -1) // Not ,y or .x
                    {
                        (value, PageZeroValue) = EvaluateExpression(rest);
                        return (PageZeroValue ? AddressMode.amZeroPage : AddressMode.amAbsolute,value);
                    }
                    var commaLetter = rest.Substring(endpos + 1).Trim();
                    rest = rest.Substring(0, endpos - 1);
                    (value, PageZeroValue) = EvaluateExpression(rest);
                    if (commaLetter == null || commaLetter.Length == 0)
                    {
                        Errors.Add("Missing X or Y after ,");
                        return (AddressMode.amUnassigned, 0);
                    }
                    if (commaLetter.ToLower()[0] == 'x')
                    {
                        return (PageZeroValue ? AddressMode.amZeroPageX : AddressMode.amAbsoluteX, value);
                    }
                    if (commaLetter.ToLower()[0] == 'y')
                    {
                        return (PageZeroValue ? AddressMode.amZeroPageY : AddressMode.amAbsoluteY, value);
                    }
                }
            }
            return (AddressMode.amUnassigned,0);
        }

        // Set ProgramCounter but page zero not allowed. Not $xx or $00xx. Evaluate distingushes between
        // $xx being page zero and $00xx NOT being page zero (technically it is but with addition can overflow into page 1)
        private void SetProgramCounter(string line)
        {
            (PC,PageZeroValue) = EvaluateExpression(line);
            if (PageZeroValue || PC <256)
            {
                Errors.Add("Cannot output code in page zero");
                return;
            }
        }

        // Evaluate simple expressions with number $2d or 25 or labels returns value and PageZero bool flag
        private (int,bool) EvaluateExpression(string line)
        {
            var value = 0;
            var expression = ""; // Used for +/- Value after value as in $5432+5
            var result = (0, false);
            if (line.Length == 0)
            {
                Errors.Add("Program Counter must be assigned a value");
                return result;
            }
            // Does expression start with $
            if (line.StartsWith("$")) // Convert to int but establish if meant to be page zero ($xx) or not e.g. $00xx
            {
                try
                {
                    value = Convert.ToInt32("0x" + line.Substring(1), 16);
                    if (value > 65535)
                    {
                        Errors.Add("Hexadecimal value is too large (must be $0-$FFFF");
                        return result;
                    }
                    if (line.Length <= 3 && value <= 255)
                    {
                        result.Item2 = true;
                    }
                    else
                    {
                        // e.g. $0078 is a page zero address but might be valid 16-bit so addition can overflow into page 1
                        // a page 0 address like $f0 can't overflow into page 1 with addition. 
                        result.Item2 = false;
                    }

                    if (expression.StartsWith("+") || expression.StartsWith("-"))
                    {
                        var factor = GetFactor(expression);
                        value += factor;
                    }
                    result.Item1 = value;
                    return result;
                }
                catch
                {
                    Errors.Add("Hexadecimal conversion failed (must be $0-$FFFF");
                    return result;
                }
            }
            else
            if (line[0] >= '0' && line[0] <= '9') // Decimal number
            {
                var i = 1;
                while (i < line.Length)
                {
                    if (line[i] < '0' || line[i] > '9') {
                        expression = line.Substring(i);
                        break;
                    }
                }
                value = int.Parse(line.Substring(0, i - 1));
                if (value > 65535)
                {
                    Errors.Add("Decimal value too large (must be $0-$FFFF");
                    return result;
                }

                if (expression.StartsWith("+") || expression.StartsWith("-"))
                {
                    var factor = GetFactor(expression);
                    value += factor;
                }
                return (value, value <= 255);
            }
            else
            {
                line = line.ToLower();  // Must be a label
                if (line[0] >= 'a' && line[0] <= 'z') // Got a label
                {
                    var label = line[0].ToString();
                    var i = 1;
                    while (i < line.Length) // Get rest of label
                    {
                        if (line[i] < 'a' || line[i] > 'z' && line[i] != ':')
                        {
                            expression = line.Substring(i);
                            break;
                        }
                        if (line[i] != ':')
                        {
                            label += line[i];
                        }
                    }
                    expression = line.Substring(i);
                    // Got full label here, possibly with an expression
                    value = labels.GetValue(label);
                    if (expression.StartsWith("+") || expression.StartsWith("-"))
                    {
                        var factor = GetFactor(expression);
                        value += factor;
                    }
                    return (value, value <= 255);
                }            
            }
            return (0,false); 
        }

        // factorString = +/-Expression (one of $hex, dec value or label)
        // call EvaluateExpression 
        private int GetFactor(string factorString)
        {
            var op = factorString[0];      // +/i     
            var (result,_) = EvaluateExpression(factorString.Substring(1));
            return result * ((op == '-') ? -1 : 1);
        }

        // Reads file into List<string>
        private List<string> ReadSourceFile(string _filename)
        {
            try
            {
                {
                    var file = File.ReadAllLines(_filename);
                    return new List<string>(file);
                }
                
            }
            catch ( Exception e)
            {
                Errors.Add($"Problem reading {_filename} - Exception {e.Message}");
                return new List<string>();
            }

        }
    }


}
