﻿/*
 Note. This code last updated over the next few days (30/7/2024).  

 Some conventions
  * Several methods return tuples, typically two values e.g. (AddressMode,int) GetAddressMode(string rest)
  * Everything is checked in lower case. You can write code in upper or lower case but it's converted to lower case
    before doing string/char comparisons.
  * Labels referred to in pass one before declared (eg a JSR/JMP to a forward label) have a value of 0 on pass one. 
    The Evaluated flag is passed back so 0 doesn't trigger a PageZero error when it's not evaluated. 

 
 */



using System.ComponentModel.DataAnnotations;
using static as65.Assembler;

namespace as65
{
    internal class Label
    {
        public int Address { get; set; } = -1;
        public bool IsPageZero { get; set; } = false;
        public string Name { get; set; } = "";
        public bool Evaluated { get; set; } = false;
    }

    internal class Labels //Note, labels are always stored in lowercase
    {
        Dictionary<string, Label> labels = new Dictionary<string, Label>();
        internal List<string> Errors {  get; set; }= new List<string>();
        internal int Pass { get; set; }   // Needed for error checking

        internal void Add(string name, int value, bool isPageZero = false)
        {
            if (labels.Keys.Contains(name))
            {
                return;
            }
            labels.Add(name.ToLower(), new Label() { Address = value, Name = name, IsPageZero = isPageZero });
        }


        internal int GetValueOfLabel(string name,ref bool Evaluated)
        {
            Evaluated = false;
            if (labels.ContainsKey(name.ToLower()))
            {
                var label = labels[name];
                Evaluated = label.Evaluated;
                if (label.Evaluated) {  
                    return label.Address; 
                }
                if (Pass==2)
                {
                    Errors.Add($"Label {name} has not been assigned a value");
                    return 0; // Marker vaslue for not evaluated
                }
            }
            return 0;
        }

        internal void SetValue(string name,int value,bool isPageZero)
        {
            if (!labels.ContainsKey(name.ToLower()))
            {
                Add(name,value, isPageZero);
            }
            var label = labels[name];
            label.Address = value;
            label.Evaluated = true;
            label.IsPageZero = isPageZero;
        }
    }
    internal class Assembler
    {
        [Flags]internal enum AddressMode {amUnassigned=0,amZeroPageX=1, amZeroPage=2,amImmediate=4,amAbsolute=8, amIndirectY=16,amIndirectX=32, 
                             amAbsoluteY=64,amAbsoluteX=128,amIndirect=256,amBranch=512,amZeroPageY=1024,amAccumulator=2048 };
        List<string> Errors = new List<string>();
        List<string> Lines = new List<string>();
        Parameters parms= new Parameters();
        Opcodes opcodes = new Opcodes();
        Labels labels= new Labels();
        string filename = "";
        int CurrentIndex = 0;
        bool Evaluated= false;
        StreamWriter? listFile;
        bool outList = false;

        int pass = 0;
        int PC = 0;
        bool PageZeroValue = false;

        internal void Run(string[] args)
        {
            labels.Errors = Errors;          
            parms.ReadParameters(args);
            filename = parms.Filename;
            Lines = ReadSourceFile(filename);
            if (Lines.Count==0)
            {
                Errors.Add($"No lines read from file {filename}");
                return;
            }
            if (AssembleSource(1))
            {
                var result = AssembleSource(2);
            }
        }

        // Call this to do each pass
        private bool AssembleSource(int _pass)
        {
            pass = _pass;
            if (parms.Verbose)
            {
                if (pass==1)
                {
                    Console.WriteLine($"Assembling {filename}");
                }
                Console.WriteLine($"Pass {pass}");
            }

            if (Lines.Count == 0)
            {
                Errors.Add($"Source File {filename} is empty");
                return false;
            }
            if (pass==2 && parms.List)
            {
                outList = true;
                listFile = new StreamWriter("list.txt");
                if (parms.Verbose)
                {
                    Console.WriteLine("Generating list.txt file.");
                }
            }
            CurrentIndex = 0;
            foreach (var line in Lines)
            {
                ProcessLine(line);
                CurrentIndex++;
            }
            if (parms.Verbose && pass==2)
            {
                Console.WriteLine($"Lines assembled: {Lines.Count}");
            }
            if (outList)
            {
                listFile!.WriteLine($"Lines assembled: {Lines.Count}");
                listFile.Close();
                listFile.Dispose();
            }
            return (Errors.Count == 0);
        }

        // return true if line starts with space or tab so not a label
        private bool StartsWithSpace(ref string line)
        {
            return line.StartsWith(" ") || line.StartsWith("\t");
        }

        private void ProcessLine(string line)
        {
            if (line.StartsWith("*="))
            {
                if (line.Length==2)
                {
                    Errors.Add("Missing program counter value");
                    return;
                }
                line = line.Substring(2);
                SetProgramCounter(line);
                return;
            }
            if (StartsWithSpace(ref line))
            {
                {
                    ProcessCode(ref line);
                    return;
                }
            }
            if (StartsWithLabel(ref line))
            {
                if (!string.IsNullOrEmpty(line) && char.IsLetter(line[0]))
                {
                    var labelName = ExtractLabel(ref line);

                    var pc = PC;
                    if (line.StartsWith('=')) // label=value
                    {
                        var value = 0;
                        (value, PageZeroValue) = EvaluateExpression(line.Substring(1).Trim(), ref Evaluated);
                        labels.SetValue(labelName, value, PageZeroValue);
                        line = "";
                        return;
                    }
                    else   // label: or label gets value from program counter
                    {
                        labels.SetValue(labelName, PC, false);
                    }
                    if (!string.IsNullOrEmpty(line)) // Is there an instruction or comment
                    {
                        ProcessCode(ref line);
                        return;
                    }

                }
            }
            else if (StartsWithHash(line)) { 
                var gap = line.IndexOf(' ');
                if (gap > -1)
                {
                    var filename = line.Substring(gap + 1).Trim();
                    IncludeFile(filename);
                    // Delete Line after included
                }
            }
    
        }

        // Includes the specified file into List<string> Lines
        private void IncludeFile(string _filename)
        {
            var newlines = ReadSourceFile(_filename);
            if (newlines.Count > 0)
            {
                Lines.InsertRange(CurrentIndex, newlines);               
            }
        }

        // returns true if first var ==# and long enough for #includes
        private bool StartsWithHash(string line)
        {
            if (line== null) return false;
            if (line[0] == '#' && line.Length > 9) return true;
            return false;   
        }

        // Extracts and returns label, extracts rest of line
        private string ExtractLabel(ref string line)
        {
            var pos = 0;
            var labelText = "";
            while (pos < line.Length)
            {
                var c = line[pos];
                if (char.IsAsciiLetterOrDigit(c))
                {
                    pos++;
                    labelText += c;
                }
                else if (c == ':')
                {  // Hit end of label
                    pos++;
                    break;
                }
                else break; 
            }
            line = line.Substring(pos); // Leave rest of line to be processed            
            return labelText;

        }

        // returns true if label starts with A..Z or a..z
        private bool StartsWithLabel(ref string line)
        {
            if (line == null) return false;
            var line2=line.ToLower();
            return (line2[0] >= 'a' && line2[0] <= 'z');
        }

        // Deals with normal lines 
        private void ProcessCode(ref string line)
        {
            if (line.Contains(";"))
            {
                var pos = line.IndexOf(";");
                line = line.Substring(0, pos - 1); // Drop comment
            }
            line = line.Trim();
            if (line.Length > 0)
            {
                ProcessInstruction(ref line);
            }

        }

        // Extract then look up 6502 instructions and compiler directives
        private void ProcessInstruction(ref string line)
        {
            var code = "";
            var rest = "";
            if (line.Length == 3)
            {
                code = line.ToUpper();
            }
            else if (line.Length >3)
            {
                rest = line.Substring(4).Trim();
                code = line.Substring(0, 3).Trim().ToUpper();
            }

            if (parms.Verbose)
            {
                if (pass == 1)
                {
                    if (outList)
                    {
                        listFile!.Write($"{PC:X} {code} {rest}       ");
                        listFile.WriteLine();
                    }
                    if (parms.Verbose)
                    {
                        Console.Write($"{PC:X} {code} {rest}       ");
                        Console.WriteLine();
                    }
                }
            }
            var opcode = opcodes.GetOpcode(code);
            if (opcode==null)
            {
                Errors.Add($"Opcode {code} not recognised.");
                return;
            }
            if (opcode.SingleByte)
            {
                PC++;
                if (rest!= "")
                {
                    Errors.Add($"Unknown text: {rest} following instruction");
                    return;
                }
            }
            else
            if (opcode.IsBranch)
            {
                var offset = 0;
                (offset, PageZeroValue) = EvaluateExpression(rest,ref Evaluated);
                offset = offset-PC-2;  // Includes instruction len (2)
                if (offset<-128 || offset>127 && Evaluated)
                {
                    Errors.Add($"Branch to label {rest} distance is too far");
                    return;
                }
                PC += 2;
                if (pass == 2)
                {
                    OutputCode(opcode, AddressMode.amBranch, offset);
                    // Emit code
                }
            }
            else
            {
                var (addressMode,value) = GetAddressMode(rest);
                if (addressMode == AddressMode.amUnassigned)
                {
                    return;
                }
                if ((opcode.Modes & (uint)addressMode)== 0) // Is not a valid address mode
                {
                    Errors.Add($"Opcode {opcode} is not consistent with address mode {addressMode}");
                    return;
                }
                PC += (PageZeroValue ? 2 : 3);
                if (pass == 2)
                {
                    OutputCode(opcode,addressMode,value);
                    // Emit code
                }
            }
        }

        // Works out what opcode should be
        private void OutputCode(Opcode opcode, AddressMode addressMode,int value=0)
        {
            var rawOpcode = opcode.Value;
            if (opcode.IsBranch)
            {

            }
        }

        // determines address mode and returns it and the value, also sets ZeroPageValue accordingly
        private (AddressMode,int) GetAddressMode(string rest,bool isBranch=false)
        {
            var value = 0;
            rest = rest.ToLower().Trim();
            if (rest.Length == 0) {
                Errors.Add($"Missing address mode etc after opcode");
                return (AddressMode.amUnassigned,0); 
            }
            var ch = rest[0];
            if (ch == '#')
            {
                (value, PageZeroValue) = EvaluateExpression(rest.Substring(1), ref Evaluated);
                if (value>256)
                {
                    Errors.Add($"Value is immediate mode must be byte sized");
                    return (AddressMode.amUnassigned, 0);
                }
                return (AddressMode.amImmediate,value);
            }
            else
                if (ch == '$' || (ch >= '0' && ch <= '9') || (ch >= 'a' && ch < 'z'))
            { // Could be any Zeropage or absolute
                var endpos = rest.IndexOf(',');
                if (endpos == -1) // Not ,y or .x
                {
                    (value, PageZeroValue) = EvaluateExpression(rest, ref Evaluated);
                    return (PageZeroValue ? AddressMode.amZeroPage : AddressMode.amAbsolute,value);
                }
                else
                {   // abs,x or ,y or zeropage,x or ,y
                    var commaLetter = rest.Substring(endpos + 1).Trim();
                    rest = rest.Substring(0, endpos - 1);
                    (value, PageZeroValue) = EvaluateExpression(rest, ref Evaluated);
                    if (commaLetter == null || commaLetter.Length == 0)
                    {
                        Errors.Add("Missing X or Y after ,");
                        return (AddressMode.amUnassigned,0);
                    }
                    if (commaLetter.ToLower()[0] == 'x')
                    {
                        return (PageZeroValue ? AddressMode.amZeroPageX : AddressMode.amAbsoluteX,value);
                    }
                    if (commaLetter.ToLower()[0] == 'y')
                    {
                        return (PageZeroValue ? AddressMode.amZeroPageY : AddressMode.amAbsoluteY,value);
                    }
                }
            }
            else if (ch == '(')
            { // (indirect), (indirect,X) or (indirect),y
                if (rest.Length == 1)
                {
                    Errors.Add("Missing text after (");
                    return (AddressMode.amUnassigned,0);
                }                
                var index = rest.IndexOf(')');
                if (index==-1)
                {
                    Errors.Add("Missing )");
                    return (AddressMode.amUnassigned, 0);
                }
                // Can be (address) for jmp or (address,x) or (address),y
                if (rest.IndexOf(',') == -1) // this code for (indirect)
                {  // jmp (Indirect)
                    var afterBracket = rest.Substring(index+1);
                    if (afterBracket.Length > 0)
                    {
                        Errors.Add("Unexpected text after )");
                        return (AddressMode.amUnassigned, 0);
                    }
                    rest = rest.Substring(1, index);  // Drop ( 
                    index = rest.IndexOf(')');
                    rest = rest.Substring(0, index - 1); // drop )

                    (value, PageZeroValue) = EvaluateExpression(rest, ref Evaluated);
                    if (PageZeroValue && Evaluated)
                    {
                        Errors.Add("Page zero addresses not allowed in jmp ()");
                        return (AddressMode.amUnassigned, 0);
                    }
                    return (AddressMode.amIndirect, value);
                }

                var endpos = rest.IndexOf(',');                    
                if (endpos == -1) // Not ,
                    {
                    (value, PageZeroValue) = EvaluateExpression(rest, ref Evaluated);
                    if (!Evaluated)  // Bad idea using absolute addressing with a forward declared label 
                                     // e.g. JMP (NotYetDeclaredLabel)
                                     // as have no idea if its page zero, so assume its not. 
                                     // If it is page zero this will cause an error as it will only gen 2 bytes not 3 on pass 2
                    {
                        return (AddressMode.amAbsolute,value);
                    }
                    return (PageZeroValue ? AddressMode.amZeroPage : AddressMode.amAbsolute,value);
                    };
                var letterAfterComma = rest.Substring(endpos + 1).Trim();
                if (letterAfterComma.Length == 0)
                {
                    Errors.Add("Missing X or Y after comma");
                    return (AddressMode.amUnassigned, 0);
                }
                // Should be X or Y
                if (letterAfterComma[0] =='x')
                {  // (value,x)
                    var valtext = rest.Substring(1,endpos-1).Trim();
                    (value, PageZeroValue) = EvaluateExpression(valtext, ref Evaluated);
                    if (!PageZeroValue && Evaluated)
                    {
                        Errors.Add("Value in ,X must be single byte");
                        return (AddressMode.amUnassigned, 0);
                    }
                    return(AddressMode.amIndirectX, value);
                }
                    else if (letterAfterComma[0] == 'y')
                { // (value),y
                    endpos = rest.IndexOf(')');
                    var valtext = rest.Substring(1, endpos-1).Trim();
                    (value, PageZeroValue) = EvaluateExpression(valtext, ref Evaluated);
                    if (!PageZeroValue && Evaluated)
                    {
                        Errors.Add("Value in ,Y must be single byte");
                        return (AddressMode.amUnassigned, 0);
                    }
                    return (AddressMode.amIndirectY, value);
                }
                else
                {
                    Errors.Add("X or Y expected after comma ");
                    return (AddressMode.amUnassigned, 0);
                }
            }
            return (AddressMode.amUnassigned,0);
        }

        // Set ProgramCounter but page zero not allowed. Not $xx or $00xx. Evaluate distingushes between
        // $xx being page zero and $00xx NOT being page zero (technically it is but with addition can overflow into page 1)
        private void SetProgramCounter(string line)
        {
            (PC,PageZeroValue) = EvaluateExpression(line, ref Evaluated);
            if (PageZeroValue || PC <256)
            {
                Errors.Add("Cannot output code in page zero");
                return;
            }
        }

        // Evaluate simple expressions with number $2d or 25 or labels returns value and PageZero bool flag
        // Evaluated is passed back so that an undefined label (with a value of 0) does not trigger
        // an error when a PageZeroValue is not allowed eg JMP (address)
        private (int,bool) EvaluateExpression(string line,ref bool _Evaluated)
        {
            Evaluated = true;  // default for all except labels
            var value = 0;
            var expression = ""; // Used for +/- Value after value as in $5432+5
            var result = (0, false);
            if (line.Length == 0)
            {
                Errors.Add("Program Counter must be assigned a value");
                return result;
            }
            // Does expression start with $
            if (line.StartsWith("$")) // Convert to int but establish if meant to be page zero ($xx) or not e.g. $00xx
            {
                try
                {
                    value = Convert.ToInt32("0x" + line.Substring(1), 16);
                    if (value > 65535)
                    {
                        Errors.Add("Hexadecimal value is too large (must be $0-$FFFF");
                        return result;
                    }
                    if (line.Length <= 3 && value <= 255)
                    {
                        result.Item2 = true;
                    }
                    else
                    {
                        // e.g. $0078 is a page zero address but might be valid 16-bit so addition can overflow into page 1
                        // a page 0 address like $f0 can't overflow into page 1 with addition. 
                        result.Item2 = false;
                    }

                    if (expression.StartsWith("+") || expression.StartsWith("-"))
                    {
                        var factor = GetFactor(expression, ref _Evaluated);
                        value += factor;
                    }
                    result.Item1 = value;
                    return result;
                }
                catch
                {
                    Errors.Add("Hexadecimal conversion failed (must be $0-$FFFF");
                    return result;
                }
            }
            else
            if (line[0] >= '0' && line[0] <= '9') // Decimal number
            {
                if (line.Length == 1)
                {
                    value = int.Parse(line);
                    return (value, true);
                }
                var i = 1;
                while (i < line.Length)
                {
                    if (line[i] < '0' || line[i] > '9') {
                        expression = line.Substring(i);
                        break;
                    }
                }
                value = int.Parse(line.Substring(0, i - 1));
                if (value > 65535)
                {
                    Errors.Add("Decimal value too large (must be $0-$FFFF");
                    return result;
                }

                if (expression.StartsWith("+") || expression.StartsWith("-"))
                {
                    var factor = GetFactor(expression, ref Evaluated);
                    value += factor;
                }
                return (value, value <= 255);
            }
            else
            {   //evaluating label in expression
                line = line.ToLower();  // Must be a label
                if (line[0] >= 'a' && line[0] <= 'z') // Got a label
                {
                    var labelName = ExtractLabel(ref line);
                    expression = line;
                    // Got full label here, possibly with an expression
                    value = labels.GetValueOfLabel(labelName, ref Evaluated);
                    if (expression.StartsWith("+") || expression.StartsWith("-"))
                    {
                        var factor = GetFactor(expression, ref Evaluated);
                        value += factor;
                    }
                    return (value, value <= 255);
                }            
            }
            return (0,false); 
        }

        // factorString = +/-Expression (one of $hex, dec value or label)
        // call EvaluateExpression 
        private int GetFactor(string factorString,ref bool _Evaluated)
        {
            var op = factorString[0];      // +/i     
            var (result,_) = EvaluateExpression(factorString.Substring(1), ref _Evaluated);
            return result * ((op == '-') ? -1 : 1);
        }

        // Reads file into List<string>
        private List<string> ReadSourceFile(string _filename)
        {
            try
            {
                {
                    var file = File.ReadAllLines(_filename);
                    return new List<string>(file);
                }
                
            }
            catch ( Exception e)
            {
                Errors.Add($"Problem reading {_filename} - Exception {e.Message}");
                return new List<string>();
            }

        }
    }


}
