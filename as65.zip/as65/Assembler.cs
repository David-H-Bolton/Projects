﻿namespace as65
{
    internal class Label
    {
        public int Address { get; set; } = -1;
        public bool IsPageZero { get; set; } = false;
        public string Name { get; set; } = "";
        public bool Evaluated { get; set; } = false;
    }
    internal class Assembler
    {
        enum AddressMode {amZeroPageX, amZeroPage,amImmediate,amAbsolute, amIndirectY,amIndirectX, amAbsoluteY,amAbsoluteX };
        List<string> Errors = new List<string>();
        List<string> Lines = new List<string>();
        string filename = "";
        int CurrentIndex = 0; 
        List<Label> Labels = new List<Label>();
        int pass = 0;
        int PC = 0;

        internal void Run(string[] args)
        {
            var parms = new Parameters(args);
            filename = parms.Filename;
            Lines = ReadSourceFile(filename);
            if (Lines.Count==0)
            {
                Errors.Add($"No lines read from file {filename}");
                return;
            }
            if (AssembleSource(1))
            {
                var result = AssembleSource(2);
            }
        }

        // Call this to do each pass
        private bool AssembleSource(int _pass)
        {
            pass = _pass;
            if (Lines.Count == 0)
            {
                Errors.Add($"Source File {filename} is empty");
                return false;
            }
            CurrentIndex = 0;
            foreach (var line in Lines)
            {
                ProcessLine(line);
                CurrentIndex++;
                if (pass == 2)
                {
                    EmitCode();
                }
            }
            return (Errors.Count == 0);
        }

        // Outputs machine code
        private void EmitCode()
        {
            throw new NotImplementedException();
        }

        // return true if line starts with space or tab so not a label
        private bool StartsWithSpace(ref string line)
        {
            return line.StartsWith(" ") || line.StartsWith("\\t");
        }

        private void ProcessLine(string line)
        {
            if (line.StartsWith("*="))
            {
                SetProgramCounter(line);
                return;
            }
            if (StartsWithSpace(ref line))
            {
                {
                    ProcessCode(ref line);
                    return;
                }
            }
            if (StartsWithLabel(ref line))
            {
                if (!string.IsNullOrEmpty(line) && char.IsLetter(line[0]))
                {
                    var label = ExtractLabel(ref line);
                    var pc = PC;
                    if (!string.IsNullOrEmpty(line)) // Is there an instruction or comment
                    {
                        ProcessCode(ref line);
                        return;
                    }

                }
            }
            else if (StartsWithHash(line)) { 
                var gap = line.IndexOf(' ');
                if (gap > -1)
                {
                    var filename = line.Substring(gap + 1).Trim();
                    IncludeFile(filename);
                    // Delete Line after included
                }
            }
    
        }

        // Includes the specified file into List<string> Lines
        private void IncludeFile(string _filename)
        {
            var newlines = ReadSourceFile(_filename);
            if (newlines.Count > 0)
            {
                Lines.InsertRange(CurrentIndex, newlines);               
            }
        }

        // returns true if first vhar ==# and long enough for #includes
        private bool StartsWithHash(string line)
        {
            if (line== null) return false;
            if (line[0] == '#' && line.Length > 9) return true;
            return false;   
        }

        // Extracts and returns label, processes rest of line
        private string ExtractLabel(ref string line)
        {
            var pos = 1;
            while (pos < line.Length)
            {
                var c = line[pos];
                if (char.IsAsciiLetterOrDigit(c))
                {
                    pos++;
                }
            }
            var label = line.Substring(0, pos);
            line = line.Substring(pos + 1);
            if (!string.IsNullOrEmpty(line) && line[0] == ':'){
                line = line.Substring(1);
            }
            return label;

        }

        // returns true if label starts with A..Z or a..z
        private bool StartsWithLabel(ref string line)
        {
            if (line == null) return false;
            var line2=line.ToUpper();
            return (line2[0] >= 'A' && line2[0] <= 'Z');
        }

        // Deals with normal lines 
        private void ProcessCode(ref string line)
        {
            if (line.Contains(";"))
            {
                var pos = line.IndexOf(";");
                line = line.Substring(0,pos-1); // Drop coimment
                if (line.Length > 0)
                {
                    ProcessInstruction(ref line);
                }
            }
        }

        // Extract then look up 6502 instructions and compiler directives
        private void ProcessInstruction(ref string line)
        {
            var code = "";
            var rest = "";
            if (line.Length == 3)
            {
                code = line;
            }
            else if (line.Length >3)
            {
                rest = line.Substring(4).Trim();
            }
            Console.WriteLine($"{PC} {code} {rest}");
        }

        // Set ProgramCounter
        private void SetProgramCounter(string line)
        {
            PC = Evaluate(line);
        }

        // Evaluate simple expressions with number $2d or 25 or labels
        private int Evaluate(string line)
        {
            if (line.Length == 0)
            {
                Errors.Add("Program Counter must be assigned a value");
                return 0;
            }
            // TBD
            return 0; 
        }

        // Reads file into List<string>
        private List<string> ReadSourceFile(string _filename)
        {
            try
            {
                {
                    var file = File.ReadAllLines(_filename);
                    return new List<string>(file);
                }
                
            }
            catch ( Exception e)
            {
                Errors.Add($"Problem reading {_filename} - Exception {e.Message}");
                return new List<string>();
            }

        }
    }


}
