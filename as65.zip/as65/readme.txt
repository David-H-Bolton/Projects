This is a work in progress version of A 6502 Assembler written in C# for .NET 8.
Date: August 1, 2024

Things remaining to do:

1. Emit Code
2. Emit prg header for -p option.
3. More testing

Format

as65 file options

where options are any (or none) of 

-p : generate prg file (bin generated if no -p)
-v : Verbose output
-l : Create out.txt file with assembly listing

eg
as65 test.asm -v
as65 test.asm - p -v -l

