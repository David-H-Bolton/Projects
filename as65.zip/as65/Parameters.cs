﻿namespace as65
{
    // manage parameters
    // commands are
    // Currently only make= gamenumber
    // e.g. make=1
    //  make_accounts=1

    class Parameters
    {
        public bool Verbose { get; set; } = false;  // Shows code generated on pass 2 if true

        public bool List { get; set; } = false;  // Generates listing on pass two into list.txt if true
        public string Error { get; set; } = "";
        public bool GeneratePRG { get; set; } = false;  // Output to .prrg if true oir .bin if false
        public string Filename { get; private set; } = "";

        public void ReadParameters(string[] args)
        {
            if (args!.Length == 0 || args!.Length > 4)
            {
                Error = "Minimum one and maximum four parameters " + string.Join(Environment.NewLine, args);
                return;
            }
            var parms = args[0];
            if (!File.Exists(parms))
            {
                Error = $"Missing file {parms}";
                return;
            }
            Filename = args[0];
            if (args!.Length <= 4)
                for (var i = 1; i < args.Length; i++)
                {
                    var options = args[i].ToLower();
                    if (options == "-p")
                    {
                        GeneratePRG = true;
                    }
                    else
                    if (options == "-v")
                    {
                        Verbose = true;
                    }
                    else
                    if (options == "-l")
                    {
                        List = true;
                    }
                }
        }
    }
}

