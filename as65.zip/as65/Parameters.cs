﻿namespace as65
{
    // manage parameters
    // commands are
    // Currently only make= gamenumber
    // e.g. make=1
    //  make_accounts=1

    class Parameters
    {
        public enum OptionValue {GenerateBinary, GeneratePRG }
        public bool Verbose { get; set; } = false;
        public string Error { get; set; } = "";
        public OptionValue Option { get; set; }= OptionValue.GenerateBinary;
        public string Filename { get; private set; } = "";


        public Parameters(string[] args)
        {
            if (args.Length == 0 || args.Length > 3)
            {
                Error = "Only one or two parameter needed - not " + string.Join(Environment.NewLine, args);
                return;
            }
            var parms = args[0];
            if (!File.Exists(parms))
            {
                Error = $"Missing file {parms}";
                return;
            }
            Filename = args[1];
            if (args.Length >= 2)
                for (var i=2;i<3;i++) {
                var options = args[i];
                if (options.ToUpper() == "-P") {
                    Option = OptionValue.GeneratePRG;
                }
                else
                 if (options.ToUpper() == "-V")
                {
                    Verbose = true;
                }
            }
        }
    }
}

