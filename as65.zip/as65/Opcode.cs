﻿using static as65.Assembler;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace as65
{

    // Each line is parsed into an Opcode and pulled out from the opcodes array of Opcode.
    // Note that the value is the actual codes for single byte instructions like tya but for the rest
    // it has to be caloculated by putting the address mode (0-7) in bits 2-5 xxxAAAxx
    internal class Opcode
    {
        public string Instruction {  get; set; }  // the 3-letter acronynm
        public byte Value { get; set; } = 0;    // the actual code
        public UInt16 Address { get; set; }= 0;
        public bool IsZeroPage { get; set; } = false; // true for zero page or #value

        public bool IsBranch {  get; set; } = false;  // Set true only for branches

        public bool IsGroupTwo {  get; set; } = false;
        public bool IsCompilerDirective { get; set; } = false;  

        public bool SingleByte { get; set; } = false; // Set true for single-byte instructions like txa, tya etc.
        public Opcode(string code,byte value,uint modes,bool singlebyte=false,bool isBranch=false,bool isCompilerDirective=false ) {
            Instruction = code;
            Value = value;
            Modes = modes;
            SingleByte = singlebyte;
            IsBranch = isBranch;
            IsCompilerDirective = isCompilerDirective;
            IsGroupTwo = "asl ror lsr rol stx ldx dec inc".IndexOf(code.ToLower())!=0;
        }
        public uint Modes { get; set; } = 0; // This is the address modes supported by the instruction

    }

    internal class Opcodes
    {

        internal Dictionary<string,Opcode> opcodes = new Dictionary<string, Opcode> ();
        internal uint AllModes = (uint)(AddressMode.amZeroPage| AddressMode.amZeroPageX | AddressMode.amImmediate | AddressMode.amAbsolute | 
                        AddressMode.amIndirectY | AddressMode.amIndirectX | AddressMode.amAbsoluteY | AddressMode.amAbsoluteX);
        internal uint STModes = (uint)(AddressMode.amZeroPage | AddressMode.amZeroPageX | AddressMode.amAbsolute |
                        AddressMode.amIndirectY | AddressMode.amIndirectX | AddressMode.amAbsoluteY | AddressMode.amAbsoluteX);
        internal uint RotModes = (uint)(AddressMode.amAccumulator | AddressMode.amZeroPage | AddressMode.amZeroPageX | AddressMode.amAbsolute |
                         AddressMode.amAbsoluteX);

        internal uint BitModes = (uint)(AddressMode.amZeroPage | AddressMode.amAbsolute);
        internal uint CMPModes = (uint)(AddressMode.amImmediate| AddressMode.amZeroPage | AddressMode.amAbsolute);
        internal uint DECModes = (uint)(AddressMode.amZeroPage | AddressMode.amZeroPageX | AddressMode.amAbsolute | AddressMode.amAbsoluteX);
        internal uint LXModes = (uint)(AddressMode.amImmediate| AddressMode.amZeroPage | AddressMode.amZeroPageY | AddressMode.amAbsolute | AddressMode.amAbsoluteY);
        internal uint LYModes = (uint)(AddressMode.amImmediate | AddressMode.amZeroPage | AddressMode.amZeroPageX | AddressMode.amAbsolute | AddressMode.amAbsoluteX);

        internal Opcodes()
        {
            opcodes.Add("ADC", new Opcode("ADC", 0x60, AllModes));
            opcodes.Add("AND", new Opcode("AND", 0x20, AllModes));
            opcodes.Add("ASL", new Opcode("ASL", 0x0A, RotModes));
            opcodes.Add("BCC", new Opcode("BCC", 0x90, (uint)AddressMode.amBranch, isBranch:true));
            opcodes.Add("BCS", new Opcode("BCS", 0xB0, (uint)AddressMode.amBranch, isBranch: true));
            opcodes.Add("BEQ", new Opcode("BEQ", 0xF0, (uint)AddressMode.amBranch, isBranch: true));
            opcodes.Add("BIT", new Opcode("BIT", 0x24, BitModes,true));
            opcodes.Add("BMI", new Opcode("BMI", 0x30, (uint)AddressMode.amBranch, isBranch: true));
            opcodes.Add("BNE", new Opcode("BNE", 0xD0, (uint)AddressMode.amBranch, isBranch: true));
            opcodes.Add("BPL", new Opcode("BPL", 0x10, (uint)AddressMode.amBranch, isBranch: true));
            opcodes.Add("BRK", new Opcode("BRK", 0x00, (uint)AddressMode.amBranch, isBranch: true));
            opcodes.Add("BVC", new Opcode("BVC", 0x50, (uint)AddressMode.amBranch, isBranch: true));
            opcodes.Add("BVS", new Opcode("BVS", 0x70, (uint)AddressMode.amBranch, isBranch: true));
            opcodes.Add("CLC", new Opcode("CLC", 0x18, 0, true));
            opcodes.Add("CLD", new Opcode("CLD", 0xD8, 0, true));
            opcodes.Add("CLI", new Opcode("CLI", 0x58, 0, true));
            opcodes.Add("CLV", new Opcode("CLV", 0xB8, 0, true));
            opcodes.Add("CMP", new Opcode("CMP", 0xC1, AllModes));
            opcodes.Add("CPX", new Opcode("CPX", 0xE0, CMPModes));
            opcodes.Add("CPY", new Opcode("CPY", 0xC0, CMPModes));
            opcodes.Add("DEC", new Opcode("DEC", 0xC6, DECModes));
            opcodes.Add("DEX", new Opcode("DEX", 0xCA, 0, true));
            opcodes.Add("DEY", new Opcode("DEY", 0x88, 0, true));
            opcodes.Add("EOR", new Opcode("EOR", 0x40, AllModes));
            opcodes.Add("INC", new Opcode("INC", 0xE6, DECModes));
            opcodes.Add("INX", new Opcode("INX", 0xE8, 0, true));
            opcodes.Add("INY", new Opcode("INY", 0xC8, 0, true));
            opcodes.Add("JMP", new Opcode("JMP", 0x4C, (uint)(AddressMode.amIndirect | AddressMode.amAbsolute)));
            opcodes.Add("JSR", new Opcode("JSR", 0x20, (uint)AddressMode.amAbsolute));
            opcodes.Add("LDA", new Opcode("LDA", 0xA0, AllModes));
            opcodes.Add("LDX", new Opcode("LDX", 0xA2, LXModes));
            opcodes.Add("LDY", new Opcode("LDY", 0xA0, LYModes));
            opcodes.Add("LSR", new Opcode("LSR", 0x4A, RotModes));
            opcodes.Add("NOP", new Opcode("NOP", 0xEA, 0, true));
            opcodes.Add("ORA", new Opcode("ORA", 0x00, AllModes));
            opcodes.Add("PHA", new Opcode("PHA", 0x48, 0, true));
            opcodes.Add("PHP", new Opcode("PHP", 0x08, 0, true));
            opcodes.Add("PLA", new Opcode("PLA", 0x68, 0, true));
            opcodes.Add("PLP", new Opcode("PLP", 0x28, 0, true));
            opcodes.Add("ROL", new Opcode("ROL", 0x2A, RotModes));
            opcodes.Add("ROR", new Opcode("ROR", 0x6A, RotModes));
            opcodes.Add("RTI", new Opcode("RTI", 0x40, 0, true));
            opcodes.Add("RTS", new Opcode("RTS", 0x60, 0, true));
            opcodes.Add("SBC", new Opcode("SBC", 0xE0, AllModes));
            opcodes.Add("SEC", new Opcode("SEC", 0x38, 0, true));
            opcodes.Add("SED", new Opcode("SED", 0xF8, 0, true));
            opcodes.Add("SEI", new Opcode("SEI", 0x78, 0, true));
            opcodes.Add("STA", new Opcode("STA", 0x81, STModes));
            opcodes.Add("STX", new Opcode("STX", 0x86, (uint)(AddressMode.amZeroPage | AddressMode.amZeroPageY | AddressMode.amAbsolute)));
            opcodes.Add("STY", new Opcode("STY", 0x84, (uint)(AddressMode.amZeroPage | AddressMode.amZeroPageX | AddressMode.amAbsolute)));
            opcodes.Add("TAX", new Opcode("TAX", 0xAA, 0, true));
            opcodes.Add("TAY", new Opcode("TAY", 0xA8, 0, true));
            opcodes.Add("TSX", new Opcode("TSX", 0xBA, 0, true));
            opcodes.Add("TXA", new Opcode("TXA", 0x8A, 0, true));
            opcodes.Add("TXS", new Opcode("TXS", 0x9A, 0, true));
            opcodes.Add("TYA", new Opcode("TYA", 0x98, 0, true));
            // Compiler directives...
            opcodes.Add("DC.B", new Opcode("DC.B", 0, 0, isCompilerDirective:true));
            opcodes.Add("DC.W", new Opcode("DC.W", 0, 0, isCompilerDirective: true));
            opcodes.Add("DC.S", new Opcode("DC.S", 0, 0, isCompilerDirective: true));

        }

        internal Opcode? GetOpcode(string opcode)
        {
            if (opcodes.ContainsKey(opcode))
            {
                return opcodes[opcode];
            }
            else
            {
                return null;
            }
        }
    }
}
