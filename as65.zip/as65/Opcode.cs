﻿namespace as65
{

    internal class Opcode
    {
        public string Instruction {  get; set; }
        public byte Value { get; set; } = 0;
        public UInt16 Address { get; set; }= 0;
        public bool IsZeroPage { get; set; } = false;
        public Opcode(string code,byte value) {
            Instruction = code;
            Value = value;
        }

    }

    internal class Opcodes
    {
        internal Dictionary<string,int> opcodes = new Dictionary<string, int> ();

        internal Opcodes() {
            opcodes.Add("ADC", 0x60);
            opcodes.Add("AND", 0x20); 
            opcodes.Add("ASL", 0x00); 
            opcodes.Add("BCC", 0x90); 
            opcodes.Add("BCS", 0xB0); 
            opcodes.Add("BEQ", 0xF0); 
            opcodes.Add("BIT", 0x24);
            opcodes.Add("BMI", 0x30);
            opcodes.Add("BNE", 0xD0);
            opcodes.Add("BPL", 0x10);
            opcodes.Add("BRK", 0x00);
            opcodes.Add("BVC", 0x50);
            opcodes.Add("BVS", 0x70);
            opcodes.Add("CLC", 0x18);
            opcodes.Add("CLD", 0xD8);
            opcodes.Add("CLI", 0x58);
            opcodes.Add("CLV", 0xB8);
            opcodes.Add("CMP", 0xC1);
            opcodes.Add("CPX", 0x69);
            opcodes.Add("DEC", 0x69);
            opcodes.Add("DEX", 0x69);
            opcodes.Add("DEY", 0x69);
            opcodes.Add("EOR", 0x40);
            opcodes.Add("INC", 0xE6);
            opcodes.Add("INX", 0x69);
            opcodes.Add("INY", 0x69);
            opcodes.Add("JMP", 0x4C);
            opcodes.Add("JSR", 0x20);
            opcodes.Add("LDA", 0xA0);
            opcodes.Add("LDX", 0xA2);
            opcodes.Add("LDY", 0xA0);
            opcodes.Add("LSR", 0x69);
            opcodes.Add("NOP", 0x69);
            opcodes.Add("ORA", 0x00);
            opcodes.Add("PHA", 0x69);
            opcodes.Add("PHP", 0x69);
            opcodes.Add("PLA", 0x69);
            opcodes.Add("PLP", 0x69);
            opcodes.Add("ROL", 0x69);
            opcodes.Add("ROR", 0x69);
            opcodes.Add("RTI", 0x69);
            opcodes.Add("RTS", 0x69);
            opcodes.Add("SBC", 0xE0);
            opcodes.Add("SEC", 0x38);
            opcodes.Add("SED", 0xF8);
            opcodes.Add("SEI", 0x69);
            opcodes.Add("STA", 0x81);
            opcodes.Add("STX", 0x69);
            opcodes.Add("STY", 0x69);
            opcodes.Add("TAX", 0x69);
            opcodes.Add("TAY", 0x69);
            opcodes.Add("TSX", 0x69);
            opcodes.Add("TXA", 0x69);
            opcodes.Add("TXS", 0x69);
            opcodes.Add("TYA", 0x69);
        }
    }
}
