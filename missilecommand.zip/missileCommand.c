// (C) 2023 LinuxFormat. Author David Bolton

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "hr_time.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <stdbool.h>
#include <sys/utsname.h>

// defines
#define WIDTH 1024
#define HEIGHT 768
#define MAXEXPLOSIONS 10
#define NUMCITIES 6
#define NUMTEXTURES 305
#define NUMMISSILES 20

// textures
// 0-299 explosion
// 300-303 cities
// 304 missile

struct explosion{
    int y,x;
    int diameter;
    int size; // starts at 2 increases to radius
};

// Used for both missiles and ABMS. 
struct missile{
    int active;
    int y,x;
    int startx, endx;
    int yend,xend;
    float xfract;
    float yvel,xvel;
    bool isABM; 
    int citytarget; // missiles only
};

struct city{
    bool active;
    int x;
    int abms;
};

struct explosion explosions[MAXEXPLOSIONS];
struct missile missiles[NUMMISSILES];
struct city cities[NUMCITIES];

SDL_Color white = {255,255,255};
SDL_Color red = {255,0,0};
SDL_Color black = {0,0,0};

// SDL variables
SDL_Renderer* renderer;
SDL_Window* window;
// 2-298 explosions 2-298
// 300-309
SDL_Texture* textures[NUMTEXTURES];
SDL_Texture* textStr;
SDL_Color textColour;

// Variables
char buffer[100];
bool restartFlag = false;
bool showTemp = false;
bool debugFlag = false;
int delayTime = 10; // MS delay while drawing/solving map. Speed up with f key or slower with s key
bool piFlag;
float lastTemp;
int tempCount,missileCount,missileCounter,missilesfired;
int flashCount,reloadCount;
bool flashOn;
float temperature;
bool buttonClicked = false;
int score, lastScore;
TTF_Font* font;

// helper functions
int Random(int max) {
    return (rand() % max);
}

// Only call if running on a RaspI. Checks piFlag
float ReadPiTemperature() {
   char buffer[10];
   char* end;
   if (!piFlag) return 0.0f;
   if (SDL_GetTicks() - tempCount < 1000) {
       return lastTemp;
   }
   tempCount = SDL_GetTicks();
   FILE* temp = fopen("/sys/class/thermal/thermal_zone0/temp", "rt");
   int numread = fread(buffer, 10, 1, temp);
   fclose(temp);
   lastTemp = strtol(buffer, &end, 10) / 1000.0f;
   return lastTemp;
}

// Prints using text at x,y pos.
void print(char * text,int x,int y){
 	SDL_Surface *surface = TTF_RenderUTF8_Blended(font, text, textColour);	
	SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);      
	SDL_Rect dest;
	dest.x = x;
	dest.y = y;
	dest.w = surface->w;
	dest.h = surface->h;
	SDL_RenderCopy(renderer, texture, NULL, &dest);	
	SDL_FreeSurface(surface);     
}

// loads a image file from text into video ram
SDL_Texture* LoadTexture(const char * afile, SDL_Renderer *ren) {
	SDL_Texture *texture = IMG_LoadTexture(ren, afile);
	if (texture == 0) {
		printf("Failed to load texture from %s", afile);
		printf("Error is %s",SDL_GetError());
	}
	return texture;
}
// Loads Textures by calling LoadTexture 
void LoadTextures() {
	for (int i = 2; i<300; i++) {
        sprintf(buffer,"images/c%d.png",i);
		textures[i] = LoadTexture(buffer, renderer);
        if (!textures[i])
          {
            printf("Not loaded %s\n",buffer);
          }
	}
	textures[300] = LoadTexture("images/city1.png", renderer);
 	textures[301] = LoadTexture("images/city2.png", renderer); 
	textures[302] = LoadTexture("images/deadcity1.png", renderer);
 	textures[303] = LoadTexture("images/deadcity2.png", renderer);  
 	textures[304] = LoadTexture("images/abm.png", renderer);               
}

// converts score to chars, output to out
void itoa(int u,char * out){
    int tempScore=score;
    int divisor = 10000;
    for (int i=0;i<5;i++) {
        int digit = tempScore/divisor;
        *out++ = ('0'+digit);  // convert e.g. to '1'1
        tempScore -= (digit * divisor);
        divisor /=10;       
    }
}

// Sets Window caption 
void SetWindowCaption() {
    strcpy(buffer, "Missile Command Score 00000");
    if (debugFlag) {
        if (piFlag) {
            float temperature = ReadPiTemperature();
            sprintf(buffer, "Missile Command Score 00000  Temperature = %3.2f C",temperature);
        }
    }
    itoa(score,&buffer[22]);    
    SDL_SetWindowTitle(window, buffer);
}

// Detects if running on a raspberry Pi and sets piFlag accordingly
void SetPiFlag() {
   piFlag = false;
   struct utsname buffer;
   if (uname(&buffer) != 0) return;
   if (strcmp(buffer.nodename, "raspberrypi") != 0) return;
   if (strcmp(buffer.machine, "armv7l") == 0 && 
       strcmp(buffer.machine, "aarch64") == 0) return;
   piFlag = true;
}

// Slow method. Not used but left in
void DrawCircle(SDL_Renderer* renderer, int x, int y, int radius)
{
    int radiusSquared = radius * radius;
    SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);  // black
    startTimer();
    for (int w = 0; w < radius * 2; w++)
    {
        for (int h = 0; h < radius * 2; h++)
        {
            int dx = radius - w; // horizontal offset
            int dy = radius - h; // vertical offset
            if ((dx * dx + dy * dy) <= radiusSquared)
            {
                SDL_RenderDrawPoint(renderer, x + dx, y + dy);
            }
        }
    }
    stopTimer();
    printf("Time = %f7.2\n",diff());

}

// Sets each active city to 5 ABMs
void ReloadABMs(){
    for (int i=0;i<NUMCITIES;i++) {
        if (cities[i].active) {
        cities[i].abms = 5;
        }
    }
}

// Calcs distance^2 between (x1,y1) and (x2,y2)
// Although the true distance is the square root, there's no
// need to use that as we're just using this for comparing distances
// and we can just as easy compare distance^2.
float CalcDistance(int x1,int y1, int x2, int y2){
    return ((x1-x2)*(x1-x2))+((y1-y2)*(y1-y2));
}

// return nearest active city to (x,y) that still has ABMS or -1 if no ABMS or cities! 
int NearestABM(int x,int y){
    int result =-1;
    int cityy= HEIGHT-30;
    float mindist=1000000;
    for (int i=0;i<NUMCITIES;i++) {
        if (cities[i].active && cities[i].abms>0) {
            float distance = CalcDistance(cities[i].x, cityy, x,y);
            if (distance < mindist) {
                mindist = distance;
                result = i;
            }
        }

    }
    return result;
}

// Return true if a city is still active
bool CitiesExist(){
    for (int i=0;i<NUMCITIES;i++) {
        if (cities[i].active) return true;
    }
    return false;
}

// Adds a missile, picks target
void AddMissile(){
    if (!CitiesExist()) return; 
    missileCounter++;
    if (missileCounter< 180+Random(30)) return; // 3-3.5 secs delay between missiles
    missileCounter =0;
    missilesfired++;
    if (missilesfired==15){ // reload abms every 15 missiles
        ReloadABMs();
        reloadCount = 120;
        missilesfired = 0;
    }
    for (int i=0;i< NUMMISSILES;i++){
        if (!missiles[i].active) { // find free slot
            missiles[i].y = 0; 
            int x = Random(WIDTH);
            missiles[i].x = x;
            missiles[i].startx = x; // remember x coord on row 0 start pos

            int citytarget;
            do {
                citytarget = Random(NUMCITIES);
                if (cities[citytarget].active){ // Only target live cities!
                    break;
                    }
                }
            while (true);

            int cityx= cities[citytarget].x+60; // Use centre of city as target x
            // missile goes from (0, x) to (cityx, HEIGHT-30)
            missiles[i].xvel = (float)(cityx-x)/(HEIGHT-30);
            missiles[i].yvel = 1;
            missiles[i].yend = HEIGHT-30;
            missiles[i].xfract = x; // holds x as a float
            missiles[i].active = true;
            missiles[i].isABM = false;
            missiles[i].citytarget = citytarget;
            break;
        }
    }

}

// Fire an ABM from closest active city with abms.
void FireABM(int x,int y,int cityindex){
    cities[cityindex].abms--; 
    for (int i=0;i< NUMMISSILES;i++){
        if (!missiles[i].active) {  // find free slot
            missiles[i].yend = y;
            missiles[i].endx = x;
            missiles[i].x = cities[cityindex].x+60;
            missiles[i].y = HEIGHT-60;
            missiles[i].xvel = (float)(x-missiles[i].x)/(HEIGHT-30-y);
            missiles[i].yvel = -1;   // It goes up!
            missiles[i].xfract = missiles[i].x; // holds x as a float 
            missiles[i].startx = missiles[i].x;    
            missiles[i].isABM = true; 
            missiles[i].active = true;  
            break;                        
        }
    }
}

// Adds an explosion into the table at any slot with size == 0
void AddExplosion(int x, int y,int _radius){
    for (int i=0;i<MAXEXPLOSIONS;i++) {       
        if (explosions[i].size == 0) { // Got one  
            explosions[i].x = x;
            explosions[i].y = y;
            explosions[i].diameter = _radius;
            explosions[i].size = 2;
            break;          
            }
        }
    buttonClicked = false;
}

// Moves both missiles and ABMs
void MoveMissiles(){
    for (int i=0;i< NUMMISSILES;i++){
        if (missiles[i].active) {
            if (!missiles[i].isABM){  // ie its a missile
                missiles[i].y++;
                if (missiles[i].y >= HEIGHT-30) { // bang
                    missiles[i].active = 0;
                    AddExplosion(missiles[i].x,HEIGHT-30,60);
                    cities[missiles[i].citytarget] .active = false;
                    cities[missiles[i].citytarget].abms = 0; // Lost all that city's abms.
                }
                else {
                    missiles[i].xfract += missiles[i].xvel;
                    missiles[i].x = (int)missiles[i].xfract;
                }
            }
            else { // ABM
                missiles[i].y--;
                if (missiles[i].y <= missiles[i].yend) { // bang
                    missiles[i].active = 0;
                    AddExplosion(missiles[i].x,missiles[i].yend,298);
                }
                else {
                    missiles[i].xfract += missiles[i].xvel;
                    missiles[i].x = (int)missiles[i].xfract;
                }
            }
        }
    }
}

// Draws Missiles and ABMs.
void DrawMissiles(){
     for (int i=0;i< NUMMISSILES;i++){
        if (missiles[i].active) {
            if (!missiles[i].isABM){
                SDL_SetRenderDrawColor(renderer, 0xff, 0x00, 0x00, 255);  // red                   
            }
            else {
                SDL_SetRenderDrawColor(renderer, 0x00, 0x00, 0x00, 255);  // black  
            }
            SDL_RenderDrawLine(renderer,
                    missiles[i].startx,
                    missiles[i].isABM ? HEIGHT-30:0,
                    missiles[i].x,
                    missiles[i].y);
        }
    }
}

// Clicking the left button comes here
void mouseClicked() {
    int x,y;
    SDL_GetMouseState(&x,&y);        
    int nearestCity = NearestABM(x,y);  
    if (nearestCity ==-1) return; // computer says no
    FireABM(x,y,nearestCity);
}

// Handles keyboard input. If loop parameter is true then it sits
// in a loop waiting for escape to be pressed or mouse click on the close button
// Otherwise it drops out immediately
void HandleInput(bool loop,bool *finished) {
    SDL_Event event;
    int keypressed = 0;

    *finished = false;
    while (!*finished) {
        if (SDL_PollEvent(&event)) {
            switch (event.type) {
            case SDL_KEYDOWN:
                keypressed = event.key.keysym.sym;
                switch (keypressed) {                
                    case SDLK_ESCAPE:
                        *finished = true;
                        break;
                    case SDLK_r: // restart but only at end
                        if (!CitiesExist()) {
                            restartFlag = true;
                            *finished = true;
                            break;
                        }
                        break;
                    case SDLK_TAB: // Toggle debug
                        debugFlag = !debugFlag;
                        SetWindowCaption();
                        break;
                    }; // switch (keypressed)                  
            case SDL_MOUSEBUTTONDOWN:
                if (event.button.button == SDL_BUTTON_LEFT){
                   mouseClicked(); 
                }
                break;

            case SDL_QUIT: /* if mouse click to close window */           
                *finished = true;
                break;
            case SDL_KEYUP: 
                break;
             /* switch */
            }

        } // if       
        if (!loop) break;
    }// while  
}

// Makes explosions grow.
void ProcessExplosions(){
    for (int i=0;i< MAXEXPLOSIONS;i++){
        if (explosions[i].size != 0){
            if (explosions[i].size >= explosions[i].diameter) {
                explosions[i].size =0; // finished
            }
            else {
              explosions[i].size+= 3;  
            }
        }
    }  
}

// Check to see if any missiles or ABMs are hit by an explosion, and if so
// blow em up. 
void CheckExplosions(){
    for (int explindex=0;explindex< MAXEXPLOSIONS;explindex++){
        if (explosions[explindex].size != 0){  // Active explosion!
            int y = explosions[explindex].y;
            int x = explosions[explindex].x;
            int radius = explosions[explindex].size/2; // current radius of explosion
            radius *= radius; // squared
            for (int i=0;i< NUMMISSILES;i++){
                if (missiles[i].active) {
                    int ym = missiles[i].y-y;
                    int xm = missiles[i].x-x;
                    ym *= ym;
                    xm *= xm;
                    if (xm + ym < radius) {
                        AddExplosion(missiles[i].x,missiles[i].y,50);
						if (!missiles[i].isABM) { // Don't get 50 points for destroying your ABM!
                            score += 50;
						}
                        missiles[i].active = false;
                    }
                }
            }
        }
    }
}


// Initialize all arrays
void InitArrays() {
    memset(explosions, 0, sizeof(explosions)); // fastest way to zeroise an array
    memset(missiles,0,sizeof(missiles));
    int x=60;
    for (int i=0;i<NUMCITIES;i++) {
        cities[i].active = true;
        cities[i].x = x;
        x += 160;  // 120 pixel width + 40 pixel gap between cities
    }
    ReloadABMs();
}


// Draw six cities each 120 pixels wide by 30 high
// Uses graphics textures 300-303. 300 and 301 are live, 302 and 303 are dead cities
void DrawCities(){
    SDL_Rect target; 
    SDL_SetRenderDrawColor(renderer, 0xff, 0x00, 0x00, 255);  // red         
    int x =60;

    target.y = HEIGHT-30;
    target.w = 120;
    target.h = 30;
    int cityoffset=0;    
    for (int i=0;i<6;i++){    
        target.x = cities[i].x;
        int deadoffset = cities[i].active ? 0 : 2;
        SDL_RenderCopy(renderer, textures[300+cityoffset+deadoffset], 0, &target);
        cityoffset=1-cityoffset;  // Only two city graphics so toggle between them
    }
    // Now draw ABM graphics just above cities
    target.y = HEIGHT-55;
    target.w = 43;
    target.h = 25;   
    for (int i=0;i<6;i++){    
        for (int r=0;r<cities[i].abms;r++){
            target.x = cities[i].x + (r*22);
            SDL_RenderCopy(renderer, textures[304], 0, &target);
        }
    }    
}

// Draw explosions.
void DrawExplosions(){
    SDL_Rect target;
    for (int i=0;i< MAXEXPLOSIONS;i++){
        if (explosions[i].size > 0){
            int size = explosions[i].size;
            target.x = explosions[i].x-(size/2); // Keeps it in the same place
            target.y = explosions[i].y-(size/2);
            target.w = size;
            target.h = size;	
            SDL_RenderCopy(renderer, textures[size], 0, &target);        
        }    
    }
}

// Draw score
void DrawScore(){ 
    if (lastScore==score) return;
    SetWindowCaption();     
    lastScore = score;
}

// Puts Game over on screen
void DrawGameOver(){
    if (flashOn) {
        textColour = red;
        sprintf(buffer,"Game Over!");
        print(buffer,WIDTH/2-20,HEIGHT/2);     
        sprintf(buffer,"Press r to restart");
        print(buffer,WIDTH/2-80,HEIGHT/2+40);             
    }
}

// Handles text flash. flashOn is set true for the first 30/60ths of a second
void CheckFlash(){
    flashCount++;
    if (flashCount >=60){
        flashCount =0;
    }
    flashOn = flashCount < 30;
}

// Show message, only called when reloadCount >0
void DrawReloadMessage(){
    textColour = red;
    sprintf(buffer,"ABMs reloaded");
    print(buffer,WIDTH/2-20,HEIGHT/2);  
}

// Called to initialise each game
void InitGame() {
    missilesfired = 0;
    score = 0;
    InitArrays();
    missileCounter =0;
    restartFlag =false;
}


// The game loop. Everything happens here
void GameLoop() {
	InitGame(); 
    bool finished = false;
    missileCount =5;
    while (!finished) {
        startTimer();
        SDL_SetRenderDrawColor(renderer, 0xa5, 0xe1, 0xff, 255);  // blue
        SDL_RenderClear(renderer);  
        CheckFlash();    
        AddMissile();
        MoveMissiles();
        CheckExplosions();
        ProcessExplosions();        
        DrawMissiles();
        DrawCities();         
        DrawExplosions();
        DrawScore();
        finished = !CitiesExist(); 
        if (finished) {
            DrawGameOver();
        }  
        else     
            if (reloadCount>0){
                reloadCount--;
                DrawReloadMessage();
            }
        stopTimer();
        SDL_RenderPresent(renderer); // flip screen
        HandleInput(false,&finished);
        if (restartFlag) break;
    };     
}

// Loads font for text output
void LoadFont() {
	font = TTF_OpenFont("images/cps.ttf", 20); // Courier Prime Sanserif from https://www.1001fonts.com/courier-prime-sans-font.html
    if (!font) {
        printf("Font failed to load");
    } 
}

// Sets up everuthing including SDL
void initSetup(){
	SetPiFlag();

    SDL_SetMainReady();
    SDL_Init(SDL_INIT_EVERYTHING);

    window = SDL_CreateWindow(
        "Missile Command", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WIDTH, HEIGHT,
        SDL_WINDOW_SHOWN
    );

    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | 
      SDL_RENDERER_PRESENTVSYNC);
 
    srand((unsigned int)time(0));
    tempCount = SDL_GetTicks();
	LoadTextures();
	if (TTF_Init() < 0) {
		printf("TTF font not initialised");
	}
	LoadFont();   
}

// Nice simple main function
int main() {//int arcg, char* args[]) {

    initSetup();
    do {
        GameLoop();
    } while (restartFlag);

    SDL_DestroyWindow(window);
    TTF_Quit();
    SDL_Quit();
    return 0;
}
